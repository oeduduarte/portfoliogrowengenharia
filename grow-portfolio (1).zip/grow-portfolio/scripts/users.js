#!/usr/bin/env node
'use strict';
// Gestão de administradores via terminal.
//   npm run users -- list
//   npm run users -- add <usuario> <senha>
//   npm run users -- passwd <usuario> [novaSenha]
//   npm run users -- remove <usuario>
const readline = require('readline');
const path = require('path');
const crypto = require('crypto');
const config = require('../server/lib/config');
const { JsonFile } = require('../server/lib/jsonfile');
const auth = require('../server/lib/auth');

const file = new JsonFile(path.join(config.dataDir, 'users.json'), null);
const ask = (q) => new Promise((r) => { const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); rl.question(q, (a) => { rl.close(); r(a); }); });

(async () => {
  const [cmd, user, pass] = process.argv.slice(2);
  let users = file.read();
  if (!users) { console.error('data/users.json ainda não existe. Inicie o servidor uma vez (npm start) para criar o administrador inicial.'); process.exit(1); }
  const find = (n) => users.find((u) => u.username.toLowerCase() === String(n).toLowerCase());
  if (cmd === 'list') { for (const u of users) console.log(`${u.username}\t${u.role}${u.mustChangePassword ? '\t(senha de desenvolvimento)' : ''}`); return; }
  if (cmd === 'add') {
    if (!auth.validUsername(user || '')) throw new Error('Usuário inválido (3-40 caracteres: letras, números, . _ -).');
    if (find(user)) throw new Error('Usuário já existe.');
    const pw = pass || await ask('Senha (mín. 10 caracteres): ');
    if (!auth.validPassword(pw)) throw new Error('Senha muito curta.');
    users.push({ id: crypto.randomBytes(6).toString('hex'), username: user, passwordHash: await auth.hashPassword(pw), role: 'admin', mustChangePassword: false, createdAt: new Date().toISOString() });
  } else if (cmd === 'passwd') {
    const u = find(user); if (!u) throw new Error('Usuário não encontrado.');
    const pw = pass || await ask('Nova senha (mín. 10 caracteres): ');
    if (!auth.validPassword(pw)) throw new Error('Senha muito curta.');
    u.passwordHash = await auth.hashPassword(pw); u.mustChangePassword = false;
  } else if (cmd === 'remove') {
    if (users.length <= 1) throw new Error('Não é possível remover o único administrador.');
    if (!find(user)) throw new Error('Usuário não encontrado.');
    users = users.filter((u) => u !== find(user));
  } else { console.log('Uso: list | add <usuario> [senha] | passwd <usuario> [senha] | remove <usuario>'); return; }
  await file.write(users);
  // invalida sessões abertas (o servidor relê ao reiniciar)
  await new JsonFile(path.join(config.dataDir, 'sessions.json'), {}).write({});
  console.log('OK. Reinicie o servidor para aplicar (sessões foram encerradas).');
})().catch((e) => { console.error('Erro:', e.message); process.exit(1); });
