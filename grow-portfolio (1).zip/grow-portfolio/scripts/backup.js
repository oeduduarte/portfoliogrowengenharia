#!/usr/bin/env node
'use strict';
// Gera backups/grow-portfolio-AAAAMMDD-HHMM.tar.gz com data/ e uploads/.
const { execFileSync } = require('child_process');
const path = require('path');
const fs = require('fs');
const config = require('../server/lib/config');
const out = path.join(config.ROOT, 'backups');
fs.mkdirSync(out, { recursive: true });
const d = new Date(); const p = (n) => String(n).padStart(2, '0');
const name = `grow-portfolio-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}.tar.gz`;
const rel = (x) => path.relative(config.ROOT, x) || '.';
execFileSync('tar', ['-czf', path.join(out, name), '-C', config.ROOT, '--exclude=data/backups', rel(config.dataDir), rel(config.uploadsDir)], { stdio: 'inherit' });
console.log('Backup criado:', path.join(out, name));
