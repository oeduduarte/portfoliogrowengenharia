#!/usr/bin/env node
'use strict';
// Remove arquivos de /uploads que não pertencem a nenhuma obra (ex.: envios abandonados no Admin).
//   npm run cleanup           -> lista
//   npm run cleanup -- --apply -> apaga
const fs = require('fs');
const path = require('path');
const config = require('../server/lib/config');
const store = require('../server/lib/store');
const used = store.allMediaUrls();
const apply = process.argv.includes('--apply');
let n = 0;
for (const kind of ['images', 'videos']) {
  const dir = path.join(config.uploadsDir, kind);
  for (const f of fs.readdirSync(dir)) {
    if (f.startsWith('.')) { if (f.endsWith('.part')) fs.unlinkSync(path.join(dir, f)); continue; }
    if (!used.has(`/uploads/${kind}/${f}`)) { n++; console.log(apply ? 'apagando' : 'órfão', `${kind}/${f}`); if (apply) fs.unlinkSync(path.join(dir, f)); }
  }
}
console.log(n ? `${n} arquivo(s) órfão(s)${apply ? ' removidos.' : '. Rode com --apply para apagar.'}` : 'Nada a limpar.');
