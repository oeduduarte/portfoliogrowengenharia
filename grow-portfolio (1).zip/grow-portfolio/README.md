# Grow Engenharia — Portfólio Oficial 2026

Portfólio digital independente do site institucional, com **interface pública**, **Admin em `/admin`** e **persistência real**.
Zero dependências npm: só Node.js 20+.

## 1. Estrutura do projeto

```
grow-portfolio/
├─ server/
│  ├─ index.js            Servidor HTTP: rotas, API, segurança, SPA
│  └─ lib/
│     ├─ config.js        Variáveis de ambiente / caminhos
│     ├─ store.js         DADOS: obras, categorias, segmentos, validação (trocável por banco)
│     ├─ auth.js          AUTENTICAÇÃO: scrypt, sessões, CSRF, limite de tentativas, múltiplos admins
│     ├─ uploads.js       UPLOADS: streaming, validação por magic bytes
│     ├─ jsonfile.js      Escrita atômica de JSON
│     └─ http.js          Estáticos, gzip/brotli, Range (vídeo)
├─ public/                INTERFACE PÚBLICA
│  ├─ index.html          Capa, apresentação, obras
│  ├─ css/                tokens (design system Grow), base, cover, portfolio, project, lightbox
│  ├─ js/                 main (roteador), views/home, views/project, lib/lightbox, lib/dom
│  └─ assets/             logo/ (SVGs oficiais, sem alteração), img/ (capa em AVIF/WebP)
├─ admin/                 ÁREA ADMINISTRATIVA (index.html, app.js, admin.css) — servida em /admin
├─ data/                  projects.json, taxonomy.json, users.json, sessions.json, backups/
├─ uploads/images|videos/ MÍDIAS enviadas pelo Admin
├─ scripts/               users.js, backup.js, cleanup-orphans.js
└─ tests/api.e2e.js       Teste de ponta a ponta (47 verificações)
```

## 2. Executar localmente

```bash
node -v            # precisa ser >= 20
npm start          # http://localhost:3000   (Admin: http://localhost:3000/admin)
npm test           # roda os testes de ponta a ponta em pasta temporária
```

## 3. Configurar o ambiente

Copie `.env.example` para `.env` e ajuste (porta, pastas, limites, HTTPS atrás de proxy). Tudo é opcional em desenvolvimento.

## 4. Usar o Admin (`/admin`)

Login inicial de **desenvolvimento**: usuário `Grow`, senha `Growportfolio2026*@` (criado só na 1ª execução e gravado como hash scrypt; a senha não existe no frontend).

- **Obras → Nova obra**: nome, categoria, segmento, cidade/UF, ano, área, método, status (Em planejamento / Em execução / Concluída), percentual (só em execução; atalhos 25/50/75/100%), descrição, informações adicionais livres.
- **Fotos**: envie várias de uma vez (otimizadas para WebP no navegador, com miniatura). Estrela = foto principal; setas ou arrastar = ordem; ✕ = remover.
- **Vídeos**: link do YouTube/Vimeo (sem autoplay, sem áudio automático) ou arquivo MP4/WebM/MOV.
- **Salvar rascunho** (não aparece no site) ou **Publicar**. **Despublicar** na lista. **Pré-visualizar** abre a obra mesmo em rascunho (exige login).
- **Lista**: setas ou arrastar mudam a ordem do portfólio público; Excluir apaga a obra e seus arquivos.
- **Categorias e segmentos**: adicionar, renomear, excluir (só se não estiverem em uso). Filtros do site só aparecem para o que existe em obras publicadas.
- **Conta e acessos**: trocar a própria senha, adicionar/remover administradores.

Campos vazios **não são exibidos** no site. Nada é inventado: o portfólio começa vazio.

## 5–7. Onde ficam os dados

| O quê | Onde |
|---|---|
| Obras | `data/projects.json` |
| Categorias/segmentos | `data/taxonomy.json` |
| Administradores (hash) / sessões | `data/users.json`, `data/sessions.json` |
| Imagens | `uploads/images/` (`<id>.webp` e `<id>-t.webp` miniatura) |
| Vídeos | arquivos em `uploads/videos/`; YouTube/Vimeo ficam só como link em `projects.json` |

Pastas configuráveis por `DATA_DIR` e `UPLOADS_DIR`. Em hospedagem, aponte-as para disco persistente.

## 8. Backup

- Automático: cópia diária de `projects.json` em `data/backups/` (30 dias).
- Completo: `npm run backup` → `backups/grow-portfolio-AAAAMMDD-HHMM.tar.gz` (data + uploads). Agende no cron do servidor.
- Restaurar: pare o servidor, extraia o `.tar.gz` na raiz do projeto, inicie.
- Limpar uploads abandonados: `npm run cleanup` (lista) / `npm run cleanup -- --apply` (apaga).

## 9. Deploy

Precisa de um host com **Node 20+ e disco persistente** (VPS, Railway, Render com disco, Fly.io com volume). Não serve em hospedagem apenas estática.

1. Envie o projeto; **defina a senha antes do 1º start**: `NODE_ENV=production GROW_ADMIN_PASSWORD='sua-senha-forte' npm start`.
2. Com `NODE_ENV=production` o servidor **se recusa a iniciar** se ainda houver a senha de desenvolvimento.
3. Coloque atrás de HTTPS (Caddy/Nginx/Cloudflare) e defina `TRUST_PROXY=1` e `COOKIE_SECURE=1`. Exemplo Nginx: `client_max_body_size 600m;` e `proxy_request_buffering off;` (uploads de vídeo).
4. Mantenha vivo com systemd ou pm2 (`pm2 start server/index.js --name grow-portfolio`).
5. Domínio sugerido: subdomínio (ex.: `portfolio.growengenharia.com.br`).

## 10. Alterar credenciais

- Pelo Admin: **Conta e acessos → Alterar minha senha**.
- Pelo terminal: `npm run users -- passwd Grow` · `npm run users -- add maria` · `npm run users -- list` · `npm run users -- remove maria` (reinicie depois).
- **A senha de desenvolvimento deve ser trocada antes de publicar.**

## 11. Dependências

Somente **Node.js ≥ 20**. Fonte **Space Grotesk** via Google Fonts (300 e 700). Para hospedar a fonte localmente, coloque os `.woff2` em `public/assets/fonts/`, troque o `<link>` por `@font-face` e remova `fonts.googleapis.com`/`fonts.gstatic.com` do CSP em `server/index.js`.

## Direção visual — refinamento (rodada 2)

- **Tipografia**: Space Grotesk 400 (texto) e 700 (destaques). Tracking -50 do Photoshop = **-0.05em** (unidade 1/1000 em), aplicado por faixa em `public/css/tokens.css`: `--tr-display` -0.05em (≥48px), `--tr-head` -0.035em, `--tr-body` -0.02em, `--tr-small` -0.01em. Títulos em Regular com palavras-chave em Bold.
- **Headline**: "Faça sua obra de **10 meses** em **60 dias**" — seção `#proposta` em `public/index.html` (logo após a capa); "60 dias" na cor #087A46.
- **Ícones**: sprite próprio em `public/assets/icons.svg` (linear, 24×24, traço 1.5). Disponíveis: engenharia, construcao, gestao, precisao, velocidade, planejamento, execucao, seguranca, projeto, topografia, sondagem, demolicao, entrega, area, local. Uso no HTML: `<svg class="ic"><use href="/assets/icons.svg#i-NOME"/></svg>`; no JS: `icon('NOME')` (`public/js/lib/dom.js`).
- **Movimento**: `public/js/lib/reveal.js` + `public/css/motion.css`. Marque elementos com `data-reveal="up|words|clip|rule|draw"` e atraso opcional `style="--d:120ms"`; números com `data-count`. Estados ocultos só existem com a classe `html.motion` (definida em `public/js/motion.js`), então **prefers-reduced-motion** e navegadores sem JS mostram tudo estático.
- **Obra concluída**: layout próprio (case visual) em `public/js/views/project.js` — hero em tela cheia "Obra entregue", texto editorial + ficha com ícones, seção "Resultado". Nunca exibe percentual, barra ou indicador de andamento.

## Rodapé: WhatsApp e Instagram

Os botões aparecem automaticamente quando configurados no `.env` (sem dado = botão oculto, nada é inventado):

```
GROW_WHATSAPP=55DDDNUMERO          # só dígitos, com DDI 55. Ex.: 5519999999999
GROW_WHATSAPP_MSG=Olá! Vim pelo portfólio da Grow Engenharia e gostaria de um orçamento.
GROW_INSTAGRAM=usuario              # com ou sem @, ou o link do perfil
```
Reinicie o servidor após alterar. O botão "Site" aponta sempre para growengenharia.com.br.

## Filtro de obras

Um único botão "Filtrar" abre o painel (bottom sheet no mobile, gaveta lateral no desktop) com Tipo (categoria), Segmento e Status. Só aparecem opções que existem em obras publicadas; o botão mostra quantos filtros estão ativos e a seleção fica na URL (`?categoria=…&segmento=…&status=…`), podendo ser compartilhada.

## 12. Manutenção futura

- **Banco de dados**: `server/lib/store.js` concentra todo o acesso a dados; troque por SQLite/Postgres mantendo as mesmas funções.
- **API**: já existe (`/api/projects` pública; `/api/admin/*` protegida por sessão + token CSRF).
- **Novos administradores**: já suportado. **Novos segmentos/categorias**: pelo Admin.
- **Textos da apresentação** ficam em `public/index.html` (seção `#apresentacao`) e usam somente informações fornecidas no design system.
- **Capa**: imagens em `public/assets/img/capa-*` (geradas da foto fornecida). Para trocar, substitua mantendo os nomes.
- **Segurança já aplicada**: hash scrypt, cookie HttpOnly/SameSite=Strict, CSRF, limite de tentativas, CSP, validação de arquivo por conteúdo, proteção contra path traversal.
