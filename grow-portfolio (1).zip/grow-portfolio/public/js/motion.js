// Carregado de forma síncrona no <head>: liga os estados iniciais das animações
// somente quando o visitante não pediu movimento reduzido. Sem JS, tudo fica visível.
if (!window.matchMedia || !matchMedia('(prefers-reduced-motion: reduce)').matches) document.documentElement.classList.add('motion');
