import { renderHome } from './views/home.js';
import { renderProject } from './views/project.js';
import { reveal } from './lib/reveal.js';

const home = document.getElementById('home');
const project = document.getElementById('project');
const scrollMemo = new Map();

/* ---- Anéis sobre o sol da capa: posição calculada pelo enquadramento real da foto ---- */
const SUN = { desktop: { x: 900 / 1968, y: 125 / 1102 }, mobile: { x: (900 - 560) / 900, y: 125 / 1102 } };
function placeRings() {
  const img = document.getElementById('cover-img');
  const rings = document.getElementById('cover-rings');
  if (!img || !rings || !img.naturalWidth) return;
  const box = img.getBoundingClientRect();
  const cover = img.closest('.cover').getBoundingClientRect();
  const mobile = matchMedia('(max-width: 759px)').matches;
  const s = mobile ? SUN.mobile : SUN.desktop;
  const iw = mobile ? 900 : 1968, ih = 1102; // mesma media query do <picture>
  const k = Math.max(box.width / iw, box.height / ih);
  const ox = (box.width - iw * k) * .5, oy = (box.height - ih * k) * (mobile ? .4 : .45);
  const cx = box.left - cover.left + ox + s.x * iw * k;
  const cy = box.top - cover.top + oy + s.y * ih * k;
  const size = Math.max(150, Math.min(box.width, box.height) * (mobile ? .46 : .24));
  Object.assign(rings.style, { width: size + 'px', height: size + 'px', left: cx - size / 2 + 'px', top: cy - size / 2 + 'px' });
  rings.classList.add('is-placed');
}
const coverImg = document.getElementById('cover-img');
if (coverImg.complete) placeRings(); else coverImg.addEventListener('load', placeRings, { once: true });
addEventListener('resize', () => requestAnimationFrame(placeRings));

/* ---- Roteador (History API) ---- */
function route(path, { restore } = {}) {
  const m = /^\/obra\/([a-z0-9-]+)\/?$/.exec(path);
  if (m) {
    home.hidden = true; project.hidden = false;
    document.documentElement.style.scrollBehavior = 'auto';
    scrollTo(0, 0);
    renderProject(m[1]).then(() => { document.documentElement.style.scrollBehavior = ''; });
  } else {
    project.hidden = true; home.hidden = false;
    document.title = 'Portfólio Oficial 2026 | Grow Engenharia';
    renderHome().then(() => {
      requestAnimationFrame(() => {
        placeRings();
        if (restore != null) scrollTo({ top: restore, behavior: 'instant' });
        else if (location.hash) document.querySelector(location.hash)?.scrollIntoView();
        else scrollTo(0, 0);
      });
    });
  }
}

/* Transição curta entre páginas (só opacidade; ignorada com movimento reduzido) */
const motionOn = () => document.documentElement.classList.contains('motion');
function navigate(fn) {
  if (!motionOn()) return fn();
  document.body.classList.add('is-leaving');
  setTimeout(() => { fn(); requestAnimationFrame(() => document.body.classList.remove('is-leaving')); }, 200);
}

document.addEventListener('click', (e) => {
  const a = e.target.closest('a[data-link]');
  if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || a.target) return;
  const url = new URL(a.href);
  if (url.origin !== location.origin) return;
  e.preventDefault();
  scrollMemo.set(location.pathname + location.search, scrollY);
  const samePage = url.pathname === location.pathname && !/^\/obra\//.test(url.pathname);
  history.pushState({}, '', url.pathname + url.search + url.hash);
  if (samePage && url.hash) { document.querySelector(url.hash)?.scrollIntoView({ behavior: motionOn() ? 'smooth' : 'auto' }); return; }
  navigate(() => route(url.pathname));
});
addEventListener('popstate', () => navigate(() => route(location.pathname, { restore: scrollMemo.get(location.pathname + location.search) })));
if ('scrollRestoration' in history) history.scrollRestoration = 'manual';

reveal(document);
route(location.pathname);
