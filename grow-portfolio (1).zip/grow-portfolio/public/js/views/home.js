import { h, clear, pad2, place, gauge, statusMark, icon } from '../lib/dom.js';
import { reveal } from '../lib/reveal.js';
import { loadProjects } from '../api.js';

const grid = () => document.getElementById('works-grid');
const count = () => document.getElementById('works-count');

let data = null;
const state = { categoria: '', segmento: '', status: '' };

export const coverOf = (p) => p.photos.find((x) => x.id === p.coverPhotoId) || p.photos[0];

function readState() {
  const q = new URLSearchParams(location.search);
  state.categoria = q.get('categoria') || ''; state.segmento = q.get('segmento') || ''; state.status = q.get('status') || '';
}
function writeState() {
  const q = new URLSearchParams();
  for (const k of Object.keys(state)) if (state[k]) q.set(k, state[k]);
  const s = q.toString();
  history.replaceState(history.state, '', location.pathname + (s ? `?${s}` : '') + location.hash);
}

function statusLine(p, label) {
  const st = label.statuses.get(p.status) || '';
  if (p.status === 'concluida') // obra entregue: sem percentual, sem barra
    return h('div', { class: 'card__status' }, icon('entrega'), h('span', null, p.year ? `Concluída em ${p.year}` : st));
  if (p.status === 'execucao' && p.progress != null)
    return h('div', { class: 'card__status' }, statusMark(p.status), h('span', null, `${st}  ${p.progress}%`), gauge(p.progress, { idle: true }));
  return h('div', { class: 'card__status' }, statusMark(p.status), h('span', null, st));
}

function card(p, i, label) {
  const c = coverOf(p);
  const seg = label.segments.get(p.segment);
  const meta = [seg, place(p)].filter(Boolean).join('  —  ');
  return h('a', { class: 'card', href: `/obra/${p.slug}`, 'data-link': '', 'data-reveal': 'card', style: { '--d': `${(i % 3) * 110}ms` }, 'aria-label': `${p.name}${meta ? ', ' + meta : ''}` },
    h('div', { class: 'card__media' },
      c ? h('img', { src: c.thumb || c.src, srcset: c.thumb && c.thumb !== c.src ? `${c.thumb} 900w, ${c.src} 2400w` : null, sizes: '(min-width:1000px) 55vw, (min-width:640px) 50vw, 100vw', alt: c.alt || '', loading: i < 2 ? 'eager' : 'lazy', decoding: 'async', width: c.w || null, height: c.h || null }) : null),
    h('span', { class: 'card__folio' }, pad2(i + 1)),
    h('div', { class: 'card__body' },
      h('h3', { class: 'card__name' }, p.name),
      meta ? h('p', { class: 'card__meta' }, meta) : null,
      statusLine(p, label)));
}

function filtered() { return data.projects.filter((p) => matches(p, state)); }

/* ---------- Filtro: um único botão que abre o painel ---------- */
const GROUPS = [
  { key: 'categoria', title: 'Tipo', list: () => data.taxonomy.categories, get: (p) => p.category },
  { key: 'segmento', title: 'Segmento', list: () => data.taxonomy.segments, get: (p) => p.segment },
  { key: 'status', title: 'Status', list: () => data.statuses, get: (p) => p.status },
];
const matches = (p, st) => (!st.categoria || p.category === st.categoria) && (!st.segmento || p.segment === st.segmento) && (!st.status || p.status === st.status);
const activeCount = () => GROUPS.filter((g) => state[g.key]).length;

function syncToolbar() {
  const n = activeCount();
  const badge = document.getElementById('filter-n');
  badge.hidden = !n; badge.textContent = String(n);
  document.getElementById('filter-open').setAttribute('aria-label', n ? `Filtrar obras (${n} ${n === 1 ? 'filtro ativo' : 'filtros ativos'})` : 'Filtrar obras');
  document.getElementById('filter-clear').hidden = !n;
}

function openPanel(label) {
  const draft = { ...state };
  const opener = document.getElementById('filter-open');
  const P = data.projects;
  const apply = h('button', { class: 'btn btn--light', type: 'button' });
  const updateApply = () => {
    const n = P.filter((p) => matches(p, draft)).length;
    apply.replaceChildren(h('span', null, n ? `Ver ${n} ${n === 1 ? 'obra' : 'obras'}` : 'Nenhuma obra'), icon('seta', 'ic btn__arrow'));
    apply.disabled = !n;
  };
  const body = h('div', { class: 'fp__body' });
  const drawGroups = () => {
    body.replaceChildren(...GROUPS.map((g) => {
      const present = g.list().filter((it) => P.some((p) => g.get(p) === it.id));
      if (present.length < 2) return null;
      const name = `f-${g.key}`;
      const opt = (id, text) => {
        const others = { ...draft, [g.key]: id };
        const n = P.filter((p) => matches(p, others)).length;
        const input = h('input', { type: 'radio', name, value: id, checked: draft[g.key] === id, onchange: () => { draft[g.key] = id; drawGroups(); updateApply(); body.querySelector(`input[name="${name}"][value="${id}"]`)?.focus(); } });
        return h('label', { class: 'opt' }, input, text, h('small', null, String(n)));
      };
      return h('fieldset', { class: 'fp__group' }, h('legend', null, g.title),
        h('div', { class: 'fp__opts' }, opt('', 'Todos'), present.map((it) => opt(it.id, it.label))));
    }).filter(Boolean));
  };
  drawGroups(); updateApply();

  const close = (commit) => {
    if (commit) { Object.assign(state, draft); writeState(); renderGrid(label); syncToolbar(); }
    root.classList.remove('is-open');
    document.removeEventListener('keydown', onKey);
    opener.setAttribute('aria-expanded', 'false');
    document.documentElement.style.overflow = '';
    const done = () => root.remove();
    matchMedia('(prefers-reduced-motion: reduce)').matches ? done() : setTimeout(done, 420);
    opener.focus();
    if (commit) document.getElementById('obras').scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
  };
  apply.addEventListener('click', () => close(true));
  const clearBtn = h('button', { class: 'linkbtn', type: 'button', onclick: () => { GROUPS.forEach((g) => { draft[g.key] = ''; }); drawGroups(); updateApply(); } }, 'Limpar');
  const closeBtn = h('button', { class: 'fp__close', type: 'button', 'aria-label': 'Fechar filtros', onclick: () => close(false) }, icon('fechar'));
  const panel = h('div', { class: 'fp__panel', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'fp-t', id: 'filter-panel' },
    h('div', { class: 'fp__head' }, h('h2', { id: 'fp-t' }, 'Filtrar obras'), closeBtn),
    body,
    h('div', { class: 'fp__foot' }, clearBtn, apply));
  const root = h('div', { class: 'fp' }, h('div', { class: 'fp__scrim', onclick: () => close(false) }), panel);
  function onKey(e) {
    if (e.key === 'Escape') close(false);
    if (e.key === 'Tab') {
      const f = [...panel.querySelectorAll('button:not([disabled]), input:checked')];
      const i = f.indexOf(document.activeElement);
      if (e.shiftKey && i <= 0) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); }
    }
  }
  document.body.append(root);
  document.documentElement.style.overflow = 'hidden';
  opener.setAttribute('aria-expanded', 'true');
  document.addEventListener('keydown', onKey);
  requestAnimationFrame(() => requestAnimationFrame(() => root.classList.add('is-open')));
  closeBtn.focus();
}

function setupFilters(label) {
  const tools = document.getElementById('filter-tools');
  const useful = GROUPS.some((g) => g.list().filter((it) => data.projects.some((p) => g.get(p) === it.id)).length >= 2);
  tools.hidden = !useful;
  if (!useful) return;
  const opener = document.getElementById('filter-open');
  const clear = document.getElementById('filter-clear');
  opener.onclick = () => openPanel(label);
  clear.onclick = () => { GROUPS.forEach((g) => { state[g.key] = ''; }); writeState(); renderGrid(label); syncToolbar(); };
  syncToolbar();
}

function renderGrid(label) {
  const g = grid();
  const list = filtered();
  clear(g);
  if (!data.projects.length) {
    g.append(h('div', { class: 'works__empty' }, h('strong', null, 'As obras serão publicadas aqui.'), h('p', null, 'O portfólio está em preparação.')));
    count().textContent = '';
    return;
  }
  if (!list.length) {
    g.append(h('div', { class: 'works__empty' }, h('strong', null, 'Nenhuma obra neste filtro.'), h('p', null, 'Escolha outra combinação de tipo, segmento ou status.')));
  } else list.forEach((p, i) => g.append(card(p, i, label)));
  const total = data.projects.length;
  count().textContent = list.length === total ? `${total} ${total === 1 ? 'obra publicada' : 'obras publicadas'}` : `${list.length} de ${total} obras`;
  reveal(g);
}

export async function renderHome() {
  readState();
  const g = grid();
  try {
    data = await loadProjects();
  } catch {
    clear(g).append(h('div', { class: 'works__empty' }, h('strong', null, 'Não foi possível carregar as obras.'), h('p', null, 'Verifique sua conexão e recarregue a página.')));
    return;
  }
  const label = {
    segments: new Map(data.taxonomy.segments.map((s) => [s.id, s.label])),
    statuses: new Map(data.statuses.map((s) => [s.id, s.label])),
  };
  // valida filtros vindos da URL
  if (state.categoria && !data.projects.some((p) => p.category === state.categoria)) state.categoria = '';
  if (state.segmento && !data.projects.some((p) => p.segment === state.segmento)) state.segmento = '';
  if (state.status && !data.projects.some((p) => p.status === state.status)) state.status = '';
  setupFilters(label);
  renderGrid(label);
}
