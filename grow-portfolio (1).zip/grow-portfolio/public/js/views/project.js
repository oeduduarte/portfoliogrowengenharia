import { h, clear, fmtArea, pad2, place, gauge, statusMark, setMeta, icon } from '../lib/dom.js';
import { reveal } from '../lib/reveal.js';
import { loadProject, loadProjects } from '../api.js';
import { openLightbox } from '../lib/lightbox.js';
import { coverOf } from './home.js';

const root = () => document.getElementById('project');
const isLandscape = (p) => !p.w || !p.h || p.w / p.h >= 1.05;

/* Mosaico editorial: linhas montadas conforme a orientação das fotos */
function buildRows(photos) {
  const rows = [];
  let i = 0, r = 0;
  while (i < photos.length) {
    const a = photos[i], b = photos[i + 1], c = photos[i + 2];
    const La = isLandscape(a), Lb = b && isLandscape(b), Lc = c && isLandscape(c);
    let row;
    if (!b) row = La ? { items: [[a, 12]], ar: 21 / 9 } : { items: [[a, 6, 4]], ar: 12 / 8.4 };
    else if (!La && !Lb && c && !Lc) { row = { items: [[a, 4], [b, 4], [c, 4]], ar: 12 / 5.3 }; i++; i++; }
    else if (La && !Lb) { row = { items: [[a, 8], [b, 4]], ar: 12 / 5.4 }; i++; }
    else if (!La && Lb) { row = { items: [[a, 4], [b, 8]], ar: 12 / 5.4 }; i++; }
    else if (La && Lb) { row = r % 2 ? { items: [[a, 5], [b, 7]], ar: 12 / 5 } : { items: [[a, 7], [b, 5]], ar: 12 / 5 }; i++; }
    else { row = { items: [[a, 6], [b, 6]], ar: 12 / 6.2 }; i++; }
    rows.push(row); i++; r++;
  }
  return rows;
}

function figure(p, idx, onOpen, { sizes, eager } = {}) {
  const ar = p.w && p.h ? (p.w / p.h).toFixed(4) : '1.5';
  return h('button', { class: 'gitem', type: 'button', style: { '--ar': ar }, 'aria-label': `Ampliar foto ${idx + 1}${p.alt ? ': ' + p.alt : ''}`, onclick: () => onOpen(idx) },
    h('img', { src: p.thumb || p.src, srcset: p.thumb && p.thumb !== p.src ? `${p.thumb} 900w, ${p.src} 2400w` : null, sizes: sizes || '(min-width:1000px) 60vw, 88vw', alt: p.alt || '', loading: eager ? 'eager' : 'lazy', decoding: 'async' }));
}

function videoItem(v) {
  const frame = h('div', { class: 'vitem__frame' });
  if (v.type === 'file') {
    frame.append(h('video', { controls: true, preload: 'none', playsinline: true, poster: v.poster || null, 'aria-label': v.title || 'Vídeo da obra' }, h('source', { src: v.src })));
  } else {
    const play = h('button', { class: 'vitem__play', type: 'button', 'aria-label': `Reproduzir vídeo${v.title ? ': ' + v.title : ''}`, onclick: () => {
      const sep = v.src.includes('?') ? '&' : '?';
      const param = v.provider === 'vimeo' ? 'autoplay=1&muted=1' : 'autoplay=1&mute=1&rel=0';
      play.replaceWith(h('iframe', { src: `${v.src}${sep}${param}`, title: v.title || 'Vídeo da obra', allow: 'autoplay; fullscreen; picture-in-picture', allowfullscreen: true, loading: 'lazy', referrerpolicy: 'strict-origin-when-cross-origin' }));
    } }, h('i'));
    frame.append(play);
  }
  return h('figure', { class: 'vitem' }, frame, v.title ? h('figcaption', { class: 'vitem__title' }, v.title) : null);
}

function specRow(label, value, ic, d = 0) { return value ? h('div', { class: 'rule', 'data-reveal': 'rule', style: { '--d': `${d}ms` } }, h('dt', null, ic ? icon(ic) : null, label), h('dd', null, value)) : null; }
function factRow(label, value, ic, d = 0) { return value ? h('div', { class: 'rule', 'data-reveal': 'rule', style: { '--d': `${d}ms` } }, icon(ic), h('dt', null, label), h('dd', null, value)) : null; }
const areaNode = (a) => (a == null ? null : [fmtArea(a), h('small', null, 'm²')]);

/* Galeria reutilizável: carrossel (mobile) + mosaico (desktop). `indexOf` mapeia para o lightbox com todas as fotos. */
function gallery(list, open, indexOf, title, countLabel) {
  const track = h('div', { class: 'gtrack', tabindex: '0', 'aria-label': 'Fotos da obra — deslize para o lado' }, list.map((ph) => figure(ph, indexOf(ph), open)));
  const bar = h('i', null, h('b'));
  const num = h('span', null, `01 / ${pad2(list.length)}`);
  const sync = () => {
    const kids = [...track.children]; const x = track.scrollLeft + 4;
    let idx = 0; kids.forEach((k, i) => { if (k.offsetLeft - kids[0].offsetLeft <= x) idx = i; });
    if (track.scrollLeft + track.clientWidth >= track.scrollWidth - 4) idx = kids.length - 1;
    num.textContent = `${pad2(idx + 1)} / ${pad2(kids.length)}`;
    bar.firstChild.style.setProperty('--p', `${((idx + 1) / kids.length) * 100}%`);
  };
  track.addEventListener('scroll', () => requestAnimationFrame(sync), { passive: true });
  requestAnimationFrame(sync);
  const mosaic = h('div', { class: 'gmosaic' }, buildRows(list).map((row) => h('div', { class: 'grow', style: { '--rar': row.ar.toFixed(4) } }, row.items.map(([ph, span, start], k) => {
    const f = figure(ph, indexOf(ph), open, { sizes: `${Math.round(span / 12 * 100)}vw` });
    f.style.gridColumn = start ? `${start} / span ${span}` : `span ${span}`;
    f.setAttribute('data-reveal', 'clip'); f.style.setProperty('--d', `${k * 120}ms`);
    return f;
  }))));
  return h('section', { class: 'pgal', 'aria-labelledby': 'gal-t' },
    title ? h('div', { class: 'sec-head' }, h('h2', { id: 'gal-t', 'data-reveal': 'words' }, title), h('span', null, countLabel)) : null,
    track, h('div', { class: 'gcount' }, num, bar), mosaic);
}

export async function renderProject(slug) {
  const el = clear(root());
  el.append(h('div', { class: 'loading', role: 'status' }, 'Carregando obra…'));
  const preview = new URLSearchParams(location.search).get('preview') === '1';
  let res;
  try { res = await loadProject(slug, preview); }
  catch (e) {
    clear(el).append(h('div', { class: 'notfound' },
      h('h1', null, e.status === 404 ? 'Obra não encontrada.' : 'Não foi possível carregar a obra.'),
      h('p', { class: 'muted' }, e.status === 404 ? 'O endereço pode ter mudado ou a obra ainda não foi publicada.' : 'Verifique sua conexão e tente novamente.'),
      h('a', { class: 'btn btn--light', href: '/#obras', 'data-link': '' }, 'Ver todas as obras')));
    setMeta({ title: 'Obra não encontrada | Grow Engenharia', description: '', image: '', url: location.href });
    return;
  }
  const { project: p, taxonomy, statuses } = res;
  const seg = taxonomy.segments.find((s) => s.id === p.segment);
  const cat = taxonomy.categories.find((c) => c.id === p.category);
  const st = statuses.find((s) => s.id === p.status);
  const cover = coverOf(p);

  setMeta({ title: `${p.name} | Grow Engenharia`, description: (p.description || `${p.name} — obra da Grow Engenharia.`).slice(0, 180), image: cover ? location.origin + cover.src : '', url: `${location.origin}/obra/${p.slug}` });

  const done = p.status === 'concluida';
  const paras = (p.description || '').split(/\n{2,}/).map((t) => t.trim()).filter(Boolean);
  const coverImg = cover ? h('img', { src: cover.src, srcset: cover.thumb && cover.thumb !== cover.src ? `${cover.thumb} 900w, ${cover.src} 2400w` : null, sizes: '100vw', alt: cover.alt || p.name, fetchpriority: 'high', decoding: 'async' }) : null;
  const bar = h('div', { class: 'phero__bar' },
    h('a', { class: 'btn btn--sm phero__back', href: '/#obras', 'data-link': '', 'aria-label': 'Voltar para o portfólio' }, icon('seta', 'ic btn__arrow btn__arrow--back'), h('span', null, 'Voltar')),
    h('a', { class: 'phero__logo', href: '/', 'data-link': '', 'aria-label': 'Grow Engenharia — início' }, h('img', { src: '/assets/logo/grow-original-branco.svg', width: 1080, height: 430, alt: 'Grow Engenharia' })));
  const tags = h('div', { class: 'phero__tags', 'data-reveal': 'up', style: { '--d': '500ms' } },
    seg ? h('span', null, seg.label) : null,
    place(p) ? h('span', null, place(p)) : null,
    done ? null : h('span', null, statusMark(p.status), st ? st.label + (p.status === 'execucao' && p.progress != null ? `  ${p.progress}%` : '') : ''));

  const allPhotos = p.photos;
  const open = (i) => openLightbox(allPhotos.map((x) => ({ src: x.src, alt: x.alt })), i);
  const indexOf = (ph) => allPhotos.indexOf(ph);
  const sections = [];

  if (done) {
    /* ---------- OBRA CONCLUÍDA: case visual ---------- */
    sections.push(h('header', { class: 'phero phero--done' }, bar,
      h('div', { class: 'phero__media' }, coverImg),
      h('div', { class: 'phero__body' },
        h('p', { class: 'phero__kicker', 'data-reveal': 'up', style: { '--d': '250ms' } }, icon('entrega'), p.year ? `Obra entregue em ${p.year}` : 'Obra entregue'),
        h('h1', { class: 'phero__name', 'data-reveal': 'words', style: { '--d': '350ms' } }, p.name), tags)));

    const facts = [
      factRow('Segmento', seg && seg.label, 'construcao', 0), factRow('Localização', place(p), 'local', 80),
      factRow('Área', areaNode(p.area), 'area', 160), factRow('Ano de entrega', p.year ? String(p.year) : '', 'planejamento', 240),
      factRow('Método construtivo', p.method, 'engenharia', 320), factRow('Categoria', cat && cat.label, 'projeto', 400),
      ...(p.extra || []).map((e, i) => factRow(e.label, e.value, 'precisao', 480 + i * 80)),
    ].filter(Boolean);
    if (paras.length || facts.length) {
      const text = paras.length ? h('div', { class: 'cintro__text' },
        h('p', { class: 'cintro__lead', 'data-reveal': 'words' }, paras[0]),
        paras.length > 1 ? h('div', { class: 'cintro__more', 'data-reveal': 'up' }, paras.slice(1).map((t) => h('p', null, t))) : null) : null;
      sections.push(h('section', { class: 'cintro', 'aria-label': 'Sobre a obra' }, h('div', { class: `cintro__in${text ? '' : ' no-text'}` },
        text, facts.length ? h('dl', { class: 'facts', 'aria-label': 'Informações da obra' }, facts) : null)));
    }
    // Resultado: fotos finais (a de capa já abriu a página)
    const rest = allPhotos.length > 1 ? allPhotos.filter((x) => x !== cover) : [];
    if (rest.length) {
      const [lead, ...others] = rest;
      sections.push(h('section', { class: 'result', 'aria-labelledby': 'res-t' },
        h('div', { class: 'sec-head' }, h('h2', { id: 'res-t', 'data-reveal': 'words' }, 'Resultado'), h('span', null, `${rest.length} ${rest.length === 1 ? 'foto' : 'fotos'}`)),
        h('button', { class: 'result__lead', type: 'button', 'data-reveal': 'clip', 'aria-label': `Ampliar foto${lead.alt ? ': ' + lead.alt : ''}`, onclick: () => open(indexOf(lead)) },
          h('img', { src: lead.src, srcset: lead.thumb && lead.thumb !== lead.src ? `${lead.thumb} 900w, ${lead.src} 2400w` : null, sizes: '100vw', alt: lead.alt || '', loading: 'lazy', decoding: 'async' })),
        others.length ? gallery(others, open, indexOf, null) : null));
    }
  } else {
    /* ---------- EM EXECUÇÃO / EM PLANEJAMENTO ---------- */
    sections.push(h('header', { class: 'phero' }, bar,
      h('div', { class: 'phero__media' }, coverImg),
      h('div', { class: 'phero__body' }, h('h1', { class: 'phero__name', 'data-reveal': 'words', style: { '--d': '350ms' } }, p.name), tags)));

    const rows = [
      specRow('Categoria', cat && cat.label, 'projeto', 0), specRow('Segmento', seg && seg.label, 'construcao', 80),
      specRow('Localização', place(p), 'local', 160),
      p.area != null ? specRow('Área', areaNode(p.area), 'area', 240) : null,
      specRow('Ano', p.year ? String(p.year) : '', 'planejamento', 320),
      specRow('Método construtivo', p.method, 'engenharia', 400),
      specRow('Status', st && st.label, 'execucao', 480),
      ...(p.extra || []).map((e, i) => specRow(e.label, e.value, 'precisao', 560 + i * 80)),
    ].filter(Boolean);
    const showProgress = p.status === 'execucao' && p.progress != null;
    if (rows.length || paras.length || showProgress) {
      const prog = showProgress ? h('aside', { class: 'progress', 'aria-labelledby': 'prog-t', 'data-reveal': 'up' },
        h('h2', { id: 'prog-t' }, 'Andamento da obra'),
        h('p', { class: 'progress__num', 'aria-label': `${p.progress}%` }, h('span', { 'data-count': String(p.progress), 'aria-hidden': 'true' }, String(p.progress)), h('small', { 'aria-hidden': 'true' }, '%')),
        gauge(p.progress, { idle: true }),
        h('div', { class: 'progress__scale', 'aria-hidden': 'true' }, ['0', '25', '50', '75', '100'].map((n) => h('span', null, n)))) : null;
      const about = paras.length ? h('section', { class: 'about-work', 'aria-labelledby': 'about-t' }, h('h2', { id: 'about-t', 'data-reveal': 'words' }, 'Sobre a obra'), h('div', { 'data-reveal': 'up' }, paras.map((t) => h('p', null, t)))) : null;
      sections.push(h('section', { class: 'pinfo' }, h('div', { class: `pinfo__in ${about && prog ? 'has-two' : prog ? 'only-progress' : ''}` },
        rows.length ? h('dl', { class: 'spec', 'aria-label': 'Informações técnicas' }, rows) : null, about, prog)));
    }
    if (allPhotos.length) sections.push(gallery(allPhotos, open, indexOf, 'Galeria', `${allPhotos.length} ${allPhotos.length === 1 ? 'foto' : 'fotos'}`));
  }

  /* Vídeos */
  const vids = p.videos && p.videos.length ? h('section', { class: 'pvid', 'aria-labelledby': 'vid-t' },
    h('div', { class: 'sec-head' }, h('h2', { id: 'vid-t', 'data-reveal': 'words' }, 'Vídeos')),
    h('div', { class: `vgrid ${p.videos.length > 1 ? 'n2' : ''}` }, p.videos.map(videoItem))) : null;

  /* Próxima obra */
  const next = h('div');
  el.replaceChildren(h('article', { class: `proj${done ? ' proj--done' : ''}` }, ...sections, vids, next));
  reveal(el);
  try {
    const all = (await loadProjects()).projects;
    const i = all.findIndex((x) => x.slug === p.slug);
    const nx = all.length > 1 && i >= 0 ? all[(i + 1) % all.length] : null;
    const link = nx ? h('a', { class: 'pnext', href: `/obra/${nx.slug}`, 'data-link': '' },
      coverOf(nx) ? h('img', { src: coverOf(nx).thumb || coverOf(nx).src, alt: '', loading: 'lazy', decoding: 'async' }) : null,
      h('div', { class: 'pnext__in' }, h('span', { class: 'pnext__lbl' }, 'Próxima obra'), h('span', { class: 'pnext__name' }, nx.name)))
      : h('a', { class: 'pnext pnext--back', href: '/#obras', 'data-link': '' }, h('div', { class: 'pnext__in' }, h('span', { class: 'pnext__lbl' }, 'Portfólio'), h('span', { class: 'pnext__name' }, 'Ver todas as obras')));
    next.replaceWith(link);
  } catch { next.remove(); }
}
