let listCache = null;
async function get(url) {
  const r = await fetch(url, { headers: { Accept: 'application/json' }, credentials: 'same-origin' });
  if (!r.ok) throw Object.assign(new Error(`HTTP ${r.status}`), { status: r.status });
  return r.json();
}
export async function loadProjects(force = false) {
  if (!listCache || force) listCache = get('/api/projects').catch((e) => { listCache = null; throw e; });
  return listCache;
}
export const loadProject = (slug, preview) => get(`/api/projects/${encodeURIComponent(slug)}${preview ? '?preview=1' : ''}`);
