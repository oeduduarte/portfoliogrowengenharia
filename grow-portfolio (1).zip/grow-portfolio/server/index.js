'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const config = require('./lib/config');
const auth = require('./lib/auth');
const store = require('./lib/store');
const uploads = require('./lib/uploads');
const { sendJson, sendText, readJson, sendFile, safeJoin } = require('./lib/http');

const CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self' https://fonts.googleapis.com",
  "style-src-attr 'unsafe-inline'",
  "font-src 'self' https://fonts.gstatic.com",
  "img-src 'self' data: blob:",
  "media-src 'self' blob:",
  "frame-src https://www.youtube-nocookie.com https://player.vimeo.com",
  "connect-src 'self'",
  "object-src 'none'", "base-uri 'self'", "form-action 'self'", "frame-ancestors 'none'",
].join('; ');

const SECURITY = {
  'Content-Security-Policy': CSP,
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'X-Frame-Options': 'DENY',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
};

const clientIp = (req) => (config.trustProxy && req.headers['x-forwarded-for'] ? String(req.headers['x-forwarded-for']).split(',')[0].trim() : req.socket.remoteAddress) || 'unknown';
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const IMMUTABLE = 'public, max-age=31536000, immutable';

/* ---------------- Rotas da API ---------------- */
function publicPayload() {
  return { projects: store.listPublished(), taxonomy: store.taxonomy(), statuses: store.STATUSES };
}

async function handleApi(req, res, url) {
  const { pathname } = url;
  const method = req.method;

  /* ---- público ---- */
  if (method === 'GET' && pathname === '/api/projects') return sendJson(res, 200, publicPayload());
  let m;
  if (method === 'GET' && (m = /^\/api\/projects\/([a-z0-9-]+)$/.exec(pathname))) {
    let p = store.getPublishedBySlug(m[1]);
    if (!p && url.searchParams.get('preview') === '1' && auth.getSession(req)) p = store.getAnyBySlug(m[1]);
    if (!p) return sendJson(res, 404, { error: 'Obra não encontrada.' });
    return sendJson(res, 200, { project: p, taxonomy: store.taxonomy(), statuses: store.STATUSES });
  }

  /* ---- login/logout/me ---- */
  if (method === 'POST' && pathname === '/api/admin/login') {
    const body = await readJson(req, 10 * 1024);
    const r = await auth.login(clientIp(req), body.username, body.password);
    if (r.error === 'rate') return sendJson(res, 429, { error: `Muitas tentativas. Aguarde ${Math.ceil(r.wait / 60)} min e tente novamente.` });
    if (r.error) return sendJson(res, 401, { error: 'Usuário ou senha incorretos.' });
    const s = auth.createSession(req, r.user);
    return sendJson(res, 200, { user: auth.publicUser(r.user), csrf: s.csrf }, { 'Set-Cookie': s.cookie });
  }

  if (!pathname.startsWith('/api/admin/')) return sendJson(res, 404, { error: 'Rota não encontrada.' });

  /* ---- a partir daqui: tudo exige sessão ---- */
  const session = auth.getSession(req);
  if (!session) return sendJson(res, 401, { error: 'Sessão expirada. Entre novamente.' });

  if (method === 'GET' && pathname === '/api/admin/me') {
    return sendJson(res, 200, { user: auth.publicUser(session.user), csrf: session.csrf, devCredentials: auth.usingDevCredentials() });
  }
  if (method !== 'GET' && !auth.csrfOk(req, session)) return sendJson(res, 403, { error: 'Requisição recusada (token inválido). Recarregue a página.' });

  if (method === 'POST' && pathname === '/api/admin/logout') {
    return sendJson(res, 200, { ok: true }, { 'Set-Cookie': auth.destroySession(req) });
  }

  // Projetos
  if (method === 'GET' && pathname === '/api/admin/projects') return sendJson(res, 200, { projects: store.listAll(), taxonomy: store.taxonomy(), statuses: store.STATUSES });
  if (method === 'POST' && pathname === '/api/admin/projects') {
    const p = await store.create(await readJson(req));
    return sendJson(res, 201, { project: p });
  }
  if (method === 'POST' && pathname === '/api/admin/projects/reorder') {
    await store.reorder((await readJson(req)).ids);
    return sendJson(res, 200, { ok: true });
  }
  if ((m = /^\/api\/admin\/projects\/([a-f0-9]+)$/.exec(pathname))) {
    if (method === 'GET') { const p = store.getById(m[1]); return p ? sendJson(res, 200, { project: p }) : sendJson(res, 404, { error: 'Obra não encontrada.' }); }
    if (method === 'PUT') { const p = await store.update(m[1], await readJson(req)); return p ? sendJson(res, 200, { project: p }) : sendJson(res, 404, { error: 'Obra não encontrada.' }); }
    if (method === 'DELETE') return (await store.remove(m[1])) ? sendJson(res, 200, { ok: true }) : sendJson(res, 404, { error: 'Obra não encontrada.' });
  }

  // Upload (corpo bruto)
  if (method === 'POST' && pathname === '/api/admin/upload') {
    const q = url.searchParams;
    const kind = q.get('kind') === 'video' ? 'video' : 'image';
    const group = /^[a-f0-9]{12}$/.test(q.get('group') || '') ? q.get('group') : null;
    const r = await uploads.receive(req, { kind, group, variant: q.get('variant') });
    return sendJson(res, 201, { url: r.url, size: r.size });
  }

  // Taxonomia
  if (method === 'POST' && (m = /^\/api\/admin\/taxonomy\/(categories|segments)$/.exec(pathname))) {
    return sendJson(res, 201, { taxonomy: await store.addTaxonomy(m[1], (await readJson(req)).label) });
  }
  if ((m = /^\/api\/admin\/taxonomy\/(categories|segments)\/([a-z0-9-]+)$/.exec(pathname))) {
    if (method === 'PUT') { const t = await store.renameTaxonomy(m[1], m[2], (await readJson(req)).label); return t ? sendJson(res, 200, { taxonomy: t }) : sendJson(res, 404, { error: 'Item não encontrado.' }); }
    if (method === 'DELETE') { const t = await store.removeTaxonomy(m[1], m[2]); return t ? sendJson(res, 200, { taxonomy: t }) : sendJson(res, 404, { error: 'Item não encontrado.' }); }
  }

  // Conta e administradores
  if (method === 'POST' && pathname === '/api/admin/account/password') {
    const b = await readJson(req, 10 * 1024);
    if (!(await auth.verifyPassword(String(b.current || ''), session.user.passwordHash)))
      return sendJson(res, 422, { error: 'A senha atual está incorreta.' });
    if (!auth.validPassword(b.next)) return sendJson(res, 422, { error: 'A nova senha precisa ter ao menos 10 caracteres.' });
    await auth.changePassword(session.user.id, b.next);
    auth.destroyUserSessions(session.user.id, session.key);
    return sendJson(res, 200, { ok: true });
  }
  if (method === 'GET' && pathname === '/api/admin/users') return sendJson(res, 200, { users: auth.listUsers() });
  if (method === 'POST' && pathname === '/api/admin/users') {
    const b = await readJson(req, 10 * 1024);
    return sendJson(res, 201, { user: await auth.addUser(String(b.username || '').trim(), b.password) });
  }
  if (method === 'DELETE' && (m = /^\/api\/admin\/users\/([a-f0-9]+)$/.exec(pathname))) {
    if (m[1] === session.user.id) return sendJson(res, 422, { error: 'Você não pode remover o próprio usuário.' });
    return (await auth.removeUser(m[1])) ? sendJson(res, 200, { ok: true }) : sendJson(res, 404, { error: 'Usuário não encontrado.' });
  }

  return sendJson(res, 404, { error: 'Rota não encontrada.' });
}

/* ---------------- Contatos do rodapé ---------------- */
function applyContacts(html) {
  const wa = /^\d{10,15}$/.test(config.whatsapp) ? `https://wa.me/${config.whatsapp}?text=${encodeURIComponent(config.whatsappMsg)}` : '';
  const ig = /^[A-Za-z0-9._]{1,30}$/.test(config.instagram) ? `https://www.instagram.com/${config.instagram}/` : '';
  const block = (h, tag, url, ph) => (url ? h.replace(ph, esc(url)) : h.replace(new RegExp(`<!--${tag}-->[\\s\\S]*?<!--/${tag}-->`), ''));
  return block(block(html, 'WA', wa, '__WHATSAPP_URL__'), 'IG', ig, '__INSTAGRAM_URL__');
}

/* ---------------- HTML com metadados dinâmicos ---------------- */
function renderIndex(res, req, slug) {
  const file = path.join(config.publicDir, 'index.html');
  let html = fs.readFileSync(file, 'utf8');
  const origin = `${config.trustProxy && req.headers['x-forwarded-proto'] ? req.headers['x-forwarded-proto'] : (req.socket.encrypted ? 'https' : 'http')}://${req.headers.host}`;
  let title = 'Portfólio Oficial 2026 | Grow Engenharia';
  let desc = 'Portfólio oficial da Grow Engenharia: obras e projetos de engenharia e construção.';
  let image = `${origin}/assets/img/og.jpg`;
  let canonical = `${origin}/`;
  if (slug) {
    const p = store.getPublishedBySlug(slug);
    if (p) {
      title = `${p.name} | Grow Engenharia`;
      desc = (p.description || `${p.name}${p.city ? ` — ${p.city}${p.uf ? '/' + p.uf : ''}` : ''}. Obra da Grow Engenharia.`).slice(0, 180);
      const cover = p.photos.find((x) => x.id === p.coverPhotoId) || p.photos[0];
      if (cover) image = origin + cover.src;
      canonical = `${origin}/obra/${p.slug}`;
    }
  }
  const meta = `<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
<link rel="canonical" href="${esc(canonical)}">
<meta property="og:type" content="website"><meta property="og:site_name" content="Grow Engenharia">
<meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(desc)}">
<meta property="og:image" content="${esc(image)}"><meta property="og:url" content="${esc(canonical)}">
<meta name="twitter:card" content="summary_large_image">`;
  html = html.replace('<!--GROW_META-->', meta);
  html = applyContacts(html);
  const buf = Buffer.from(html);
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': buf.length, 'Cache-Control': 'no-cache' });
  res.end(req.method === 'HEAD' ? undefined : buf);
}

/* ---------------- Servidor ---------------- */
const server = http.createServer(async (req, res) => {
  for (const [k, v] of Object.entries(SECURITY)) res.setHeader(k, v);
  if (isSecureReq(req)) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
  const url = new URL(req.url, 'http://localhost');
  const { pathname } = url;
  try {
    if (pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') return sendText(res, 405, 'Método não permitido');

    // Uploads (mídias) — imutáveis, com suporte a Range
    if (pathname.startsWith('/uploads/')) {
      const f = safeJoin(config.uploadsDir, pathname.slice('/uploads'.length));
      if (f && path.basename(f)[0] !== '.' && sendFile(req, res, f, { cache: IMMUTABLE })) return;
      return sendText(res, 404, 'Não encontrado');
    }

    // Admin: HTML em /admin, ativos em /_admin/
    if (pathname === '/admin' || pathname === '/admin/') {
      res.setHeader('X-Robots-Tag', 'noindex, nofollow');
      if (sendFile(req, res, path.join(config.adminDir, 'index.html'), { cache: 'no-store' })) return;
    }
    if (pathname.startsWith('/_admin/')) {
      const f = safeJoin(config.adminDir, pathname.slice('/_admin'.length));
      if (f && sendFile(req, res, f, { cache: 'no-cache' })) return;
      return sendText(res, 404, 'Não encontrado');
    }

    // Públicos estáticos
    if (pathname !== '/' && !pathname.startsWith('/obra/')) {
      const f = safeJoin(config.publicDir, pathname);
      if (f && f !== path.join(config.publicDir, 'index.html')) {
        const long = /^\/assets\/(img|logo)\//.test(pathname) ? 'public, max-age=2592000' : 'no-cache';
        if (sendFile(req, res, f, { cache: long })) return;
      }
      if (path.extname(pathname)) return sendText(res, 404, 'Não encontrado');
    }

    // Rotas do app público (SPA)
    const mm = /^\/obra\/([a-z0-9-]+)\/?$/.exec(pathname);
    return renderIndex(res, req, mm ? mm[1] : null);
  } catch (e) {
    const status = e.status || 500;
    if (status >= 500) console.error('[erro]', req.method, req.url, e);
    if (res.headersSent) return res.end();
    if (pathname.startsWith('/api/')) return sendJson(res, status, { error: status >= 500 ? 'Erro interno do servidor.' : e.message, fields: e.fields });
    sendText(res, status, 'Erro');
  }
});
function isSecureReq(req) { return config.cookieSecure || (config.trustProxy && req.headers['x-forwarded-proto'] === 'https'); }

server.requestTimeout = 0;           // uploads de vídeo podem demorar
server.headersTimeout = 30000;
server.keepAliveTimeout = 5000;

(async () => {
  await auth.init();
  if (config.isProd && auth.usingDevCredentials()) {
    console.error('\n[SEGURANÇA] O Admin ainda usa a senha de desenvolvimento.');
    console.error('Em produção, altere-a antes de iniciar: `npm run users -- passwd Grow` (ou defina GROW_ADMIN_PASSWORD antes da 1ª execução).\n');
    process.exit(1);
  }
  server.listen(config.port, config.host, () => {
    console.log(`Grow Portfólio em http://localhost:${config.port}  (Admin: /admin)  [${config.env}]`);
    console.log(`Dados: ${config.dataDir}\nUploads: ${config.uploadsDir}`);
    if (auth.usingDevCredentials()) console.log('⚠ Credenciais de desenvolvimento ativas — altere antes de publicar.');
  });
})();
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => server.close(() => process.exit(0)));
