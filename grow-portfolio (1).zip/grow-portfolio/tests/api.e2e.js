'use strict';
// Teste de ponta a ponta da API: sobe um servidor isolado (dados temporários) e percorre o fluxo
// CRIAR → SALVAR → PUBLICAR → VISUALIZAR → EDITAR → ATUALIZAR → VISUALIZAR → EXCLUIR, além de auth/segurança.
const { spawn } = require('child_process');
const fs = require('fs'), os = require('os'), path = require('path');
const assert = require('assert');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'grow-e2e-'));
const PORT = 3900 + Math.floor(Math.random() * 90);
const base = `http://127.0.0.1:${PORT}`;
const env = { ...process.env, PORT: String(PORT), DATA_DIR: path.join(tmp, 'data'), UPLOADS_DIR: path.join(tmp, 'uploads'), NODE_ENV: 'development', GROW_ADMIN_PASSWORD: '' };
delete env.GROW_ADMIN_PASSWORD;
const srv = spawn(process.execPath, [path.join(__dirname, '..', 'server', 'index.js')], { env, stdio: 'pipe' });
let log = ''; srv.stdout.on('data', (d) => (log += d)); srv.stderr.on('data', (d) => (log += d));

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let cookie = '', csrf = '';
async function call(method, url, body, opts = {}) {
  const headers = { ...(opts.headers || {}) };
  if (cookie && !opts.noCookie) headers.Cookie = cookie;
  if (csrf && method !== 'GET' && !opts.noCsrf) headers['X-CSRF-Token'] = csrf;
  let payload = body;
  if (body !== undefined && !Buffer.isBuffer(body)) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const r = await fetch(base + url, { method, headers, body: payload, redirect: 'manual' });
  const sc = r.headers.get('set-cookie'); if (sc && !opts.noCookie) cookie = sc.split(';')[0];
  const ct = r.headers.get('content-type') || '';
  return { status: r.status, headers: r.headers, data: ct.includes('json') ? await r.json() : await r.text() };
}
let passed = 0;
const ok = (name) => { passed++; console.log('  ✓', name); };

// WebP 1x1 mínimo válido e JPEG mínimo
const WEBP = Buffer.from('UklGRhoAAABXRUJQVlA4TA4AAAAvAAAAAAfQ//73v/+BiOh/AAA=', 'base64');
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');

(async () => {
  for (let i = 0; i < 50; i++) { try { await fetch(base + '/api/projects'); break; } catch { await sleep(100); } }
  console.log('Público');
  let r = await call('GET', '/');
  assert.equal(r.status, 200); assert(r.data.includes('Portfólio oficial')); ok('capa responde com o HTML');
  assert(/Content-Security-Policy/i.test([...r.headers.keys()].join()) ); ok('cabeçalhos de segurança presentes');
  r = await call('GET', '/api/projects'); assert.deepEqual(r.data.projects, []); ok('portfólio vazio no início (nada inventado)');
  r = await call('GET', '/../../etc/passwd'); assert(r.status === 404 || r.status === 200 && !String(r.data).includes('root:')); ok('path traversal bloqueado');
  r = await call('GET', '/uploads/..%2f..%2fdata/users.json'); assert.notEqual(r.status, 200); ok('users.json inacessível via /uploads');
  r = await call('GET', '/data/users.json'); assert(!String(r.data).includes('scrypt')); ok('pasta data/ não é pública');

  console.log('Admin — bloqueio e login');
  r = await call('GET', '/api/admin/projects'); assert.equal(r.status, 401); ok('rota admin bloqueada sem sessão');
  r = await call('POST', '/api/admin/projects', { name: 'x' }); assert.equal(r.status, 401); ok('criação bloqueada sem sessão');
  r = await call('POST', '/api/admin/login', { username: 'Grow', password: 'errada' }); assert.equal(r.status, 401); ok('senha errada rejeitada');
  r = await call('POST', '/api/admin/login', { username: 'Grow', password: 'Growportfolio2026*@' });
  assert.equal(r.status, 200); csrf = r.data.csrf; assert(/HttpOnly/i.test(r.headers.get('set-cookie'))); assert(/SameSite=Strict/i.test(r.headers.get('set-cookie'))); ok('login com credenciais iniciais (cookie HttpOnly + SameSite=Strict)');
  r = await call('GET', '/api/admin/me'); assert.equal(r.data.devCredentials, true); ok('aviso de credencial de desenvolvimento ativo');
  r = await call('POST', '/api/admin/projects', { name: 'x' }, { noCsrf: true }); assert.equal(r.status, 403); ok('CSRF: mutação sem token recusada');
  assert(!(fs.readFileSync(path.join(tmp, 'data', 'users.json'), 'utf8')).includes('Growportfolio2026')); ok('senha não é gravada em texto puro');

  console.log('Uploads');
  r = await call('POST', '/api/admin/upload?kind=image&group=aaaaaaaaaaaa', Buffer.from('isto não é imagem 0123456789'), { headers: { 'Content-Type': 'application/octet-stream' } });
  assert.equal(r.status, 415); ok('arquivo que não é imagem recusado (magic bytes)');
  r = await call('POST', '/api/admin/upload?kind=image&group=aaaaaaaaaaaa', WEBP, { headers: { 'Content-Type': 'application/octet-stream' } });
  assert.equal(r.status, 201); const img1 = r.data.url; assert(img1.endsWith('.webp')); ok('upload de imagem WebP');
  r = await call('POST', '/api/admin/upload?kind=image&variant=thumb&group=aaaaaaaaaaaa', WEBP, { headers: { 'Content-Type': 'application/octet-stream' } });
  const thumb1 = r.data.url; assert(thumb1.includes('-t.')); ok('upload da miniatura');
  r = await call('POST', '/api/admin/upload?kind=image&group=bbbbbbbbbbbb', PNG, { headers: { 'Content-Type': 'application/octet-stream' } });
  const img2 = r.data.url; assert(img2.endsWith('.png')); ok('upload de imagem PNG');
  const mp4 = Buffer.concat([Buffer.from([0, 0, 0, 24]), Buffer.from('ftypisom'), Buffer.alloc(300, 1)]);
  r = await call('POST', '/api/admin/upload?kind=video', mp4, { headers: { 'Content-Type': 'application/octet-stream' } });
  assert.equal(r.status, 201); const vid = r.data.url; ok('upload de vídeo MP4');
  r = await call('GET', vid, undefined, { headers: { Range: 'bytes=0-9' }, noCookie: true }); assert.equal(r.status, 206); ok('vídeo servido com Range (seek)');

  console.log('Fluxo CRIAR → SALVAR → PUBLICAR → VISUALIZAR → EDITAR → ATUALIZAR → VISUALIZAR');
  r = await call('POST', '/api/admin/projects', { name: '', published: false }); assert.equal(r.status, 422); assert(r.data.fields.name); ok('validação: nome obrigatório');
  r = await call('POST', '/api/admin/projects', { name: 'Obra Teste', category: 'comercial', segment: 'farmacias', city: 'Rio de Janeiro', uf: 'rj', status: 'execucao', progress: 50, area: '1200,5', year: 2026,
    description: 'Primeiro parágrafo.\n\nSegundo parágrafo.', photos: [{ src: img1, thumb: thumb1, w: 1, h: 1 }, { src: img2 }], videos: [{ type: 'file', src: vid, title: 'Vídeo' }, { type: 'embed', url: 'https://youtu.be/dQw4w9WgXcQ' }, { type: 'embed', url: 'https://evil.example/x' }], published: false });
  assert.equal(r.status, 422); assert(r.data.fields.videos); ok('validação: link de vídeo fora de YouTube/Vimeo recusado');
  r = await call('POST', '/api/admin/projects', { name: 'Obra Teste', category: 'comercial', segment: 'farmacias', city: 'Rio de Janeiro', uf: 'rj', status: 'execucao', progress: 50, area: '1200,5', year: 2026,
    description: 'Primeiro parágrafo.\n\nSegundo parágrafo.', photos: [{ src: img1, thumb: thumb1, w: 1, h: 1 }, { src: img2 }], videos: [{ type: 'file', src: vid, title: 'Vídeo' }, { type: 'embed', url: 'https://youtu.be/dQw4w9WgXcQ' }], published: false });
  assert.equal(r.status, 201); const p = r.data.project;
  assert.equal(p.slug, 'obra-teste'); assert.equal(p.uf, 'RJ'); assert.equal(p.area, 1200.5); assert.equal(p.coverPhotoId, p.photos[0].id); ok('criar como rascunho (slug, UF, área, foto principal automáticos)');
  r = await call('GET', '/api/projects/obra-teste', undefined, { noCookie: true }); assert.equal(r.status, 404); ok('rascunho NÃO aparece no público');
  r = await call('GET', '/api/projects/obra-teste?preview=1', undefined, { noCookie: true }); assert.equal(r.status, 404); ok('pré-visualização exige sessão');
  r = await call('GET', '/api/projects/obra-teste?preview=1'); assert.equal(r.status, 200); ok('pré-visualização do rascunho com sessão');
  r = await call('PUT', `/api/admin/projects/${p.id}`, { ...p, published: true, category: '' }); assert.equal(r.status, 422); ok('publicar sem categoria é recusado');
  r = await call('PUT', `/api/admin/projects/${p.id}`, { ...p, published: true }); assert.equal(r.status, 200); ok('publicar');
  r = await call('GET', '/api/projects', undefined, { noCookie: true }); assert.equal(r.data.projects.length, 1); assert.equal(r.data.projects[0].name, 'Obra Teste'); assert(!('published' in r.data.projects[0]) ); ok('obra publicada aparece no público');
  r = await call('GET', '/obra/obra-teste', undefined, { noCookie: true }); assert(r.data.includes('<title>Obra Teste | Grow Engenharia</title>')); assert(r.data.includes('og:image')); ok('página da obra com título/OG dinâmicos');

  const cur = (await call('GET', `/api/admin/projects/${p.id}`)).data.project;
  const swapped = [cur.photos[1], cur.photos[0]];
  r = await call('PUT', `/api/admin/projects/${p.id}`, { ...cur, name: 'Obra Teste Editada', status: 'concluida', progress: 80, photos: swapped, coverPhotoId: cur.photos[1].id, extra: [{ label: 'Pavimentos', value: '2' }, { label: '', value: 'x' }], videos: [] });
  assert.equal(r.status, 200); const up = r.data.project;
  assert.equal(up.name, 'Obra Teste Editada'); assert.equal(up.progress, null, 'progresso zera fora de "em execução"'); assert.equal(up.photos[0].id, cur.photos[1].id); assert.equal(up.coverPhotoId, cur.photos[1].id); assert.equal(up.extra.length, 1); assert.equal(up.slug, 'obra-teste');
  ok('editar: nome, status, ordem das fotos, foto principal, extras, remoção de vídeo');
  assert(!fs.existsSync(path.join(tmp, 'uploads', 'videos', path.basename(vid)))); ok('vídeo removido do projeto é apagado do disco');
  r = await call('GET', '/api/projects/obra-teste', undefined, { noCookie: true }); assert.equal(r.data.project.name, 'Obra Teste Editada'); assert.equal(r.data.project.status, 'concluida'); ok('alteração refletida no público');

  console.log('Ordem, taxonomia, persistência');
  r = await call('POST', '/api/admin/projects', { name: 'Segunda Obra', category: 'industrial', published: false }); const p2 = r.data.project;
  r = await call('GET', '/api/admin/projects'); assert.equal(r.data.projects[0].id, p2.id); ok('nova obra entra no topo');
  r = await call('POST', '/api/admin/projects/reorder', { ids: [p.id, p2.id] }); assert.equal(r.status, 200);
  r = await call('GET', '/api/admin/projects'); assert.equal(r.data.projects[0].id, p.id); ok('reordenar obras');
  r = await call('POST', '/api/admin/taxonomy/segments', { label: 'Supermercados' }); assert.equal(r.status, 201); ok('novo segmento');
  r = await call('DELETE', '/api/admin/taxonomy/segments/farmacias'); assert.equal(r.status, 422); ok('segmento em uso não pode ser excluído');
  const dataFile = JSON.parse(fs.readFileSync(path.join(tmp, 'data', 'projects.json'), 'utf8')); assert.equal(dataFile.projects.length, 2); ok('persistido em data/projects.json');

  console.log('Contas');
  r = await call('POST', '/api/admin/account/password', { current: 'errada', next: 'NovaSenhaForte123' }); assert.equal(r.status, 422); ok('troca de senha exige senha atual');
  r = await call('POST', '/api/admin/users', { username: 'segundo', password: 'curta' }); assert.equal(r.status, 422); ok('senha curta recusada');
  r = await call('POST', '/api/admin/users', { username: 'segundo', password: 'SenhaSegura2026' }); assert.equal(r.status, 201); ok('adicionar outro administrador');
  r = await call('POST', '/api/admin/account/password', { current: 'Growportfolio2026*@', next: 'NovaSenhaForte123' }); assert.equal(r.status, 200); ok('alterar a própria senha');
  r = await call('GET', '/api/admin/me'); assert.equal(r.data.devCredentials, false); ok('aviso de senha de desenvolvimento some após a troca');

  console.log('Exclusão e logout');
  r = await call('DELETE', `/api/admin/projects/${p.id}`); assert.equal(r.status, 200);
  assert(!fs.existsSync(path.join(tmp, 'uploads', 'images', path.basename(img1)))); ok('excluir obra apaga também as fotos do disco');
  r = await call('GET', '/api/projects/obra-teste', undefined, { noCookie: true }); assert.equal(r.status, 404); ok('obra excluída some do público');
  r = await call('POST', '/api/admin/logout'); assert.equal(r.status, 200); cookie = '';
  r = await call('GET', '/api/admin/projects'); assert.equal(r.status, 401); ok('logout encerra o acesso');
  // sessão antiga não pode ser reaproveitada
  r = await call('POST', '/api/admin/login', { username: 'Grow', password: 'Growportfolio2026*@' }); assert.equal(r.status, 401); ok('senha antiga não funciona mais');
  r = await call('POST', '/api/admin/login', { username: 'grow', password: 'NovaSenhaForte123' }); assert.equal(r.status, 200); ok('login (usuário sem diferenciar maiúsculas) com a nova senha');

  console.log(`\n${passed} verificações passaram.`);
})().then(() => { srv.kill(); fs.rmSync(tmp, { recursive: true, force: true }); process.exit(0); })
  .catch((e) => { console.error('\nFALHOU:', e.stack || e); console.error('--- log do servidor ---\n' + log); srv.kill(); process.exit(1); });
