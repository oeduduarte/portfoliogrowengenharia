import { h, clear, place } from '/js/lib/dom.js';

const app = document.getElementById('app');
const toasts = document.getElementById('toasts');
const state = { csrf: '', me: null, dev: false, taxonomy: null, statuses: [], projects: [] };

/* ---------------- infra ---------------- */
class ApiError extends Error { constructor(m, status, fields) { super(m); this.status = status; this.fields = fields || {}; } }

async function api(method, url, body) {
  const opt = { method, credentials: 'same-origin', headers: { Accept: 'application/json' } };
  if (method !== 'GET') opt.headers['X-CSRF-Token'] = state.csrf;
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  const r = await fetch(url, opt);
  let data = {};
  try { data = await r.json(); } catch { /* sem corpo */ }
  if (r.status === 401 && !url.endsWith('/login')) { state.me = null; renderLogin('Sessão expirada. Entre novamente.'); throw new ApiError('Sessão expirada.', 401); }
  if (!r.ok) throw new ApiError(data.error || 'Erro inesperado.', r.status, data.fields);
  return data;
}

function toast(msg, err = false) {
  const t = h('div', { class: `toast${err ? ' toast--err' : ''}`, role: err ? 'alert' : 'status' }, msg);
  toasts.append(t);
  setTimeout(() => t.remove(), err ? 6000 : 3200);
}

function confirmBox({ title, text, ok = 'Confirmar', danger = false }) {
  return new Promise((resolve) => {
    const prev = document.activeElement;
    const done = (v) => { box.remove(); document.removeEventListener('keydown', key); prev && prev.focus && prev.focus(); resolve(v); };
    const key = (e) => { if (e.key === 'Escape') done(false); };
    const cancel = h('button', { class: 'b b--ghost', type: 'button', onclick: () => done(false) }, 'Cancelar');
    const yes = h('button', { class: `b ${danger ? 'b--danger' : 'b--primary'}`, type: 'button', onclick: () => done(true) }, ok);
    const box = h('div', { class: 'modal', role: 'alertdialog', 'aria-modal': 'true', 'aria-labelledby': 'cb-t' },
      h('div', { class: 'modal__box' }, h('h2', { id: 'cb-t' }, title), text ? h('p', null, text) : null, h('div', { class: 'modal__act' }, cancel, yes)));
    document.body.append(box); document.addEventListener('keydown', key); cancel.focus();
  });
}

const svg = (d) => { const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('aria-hidden', 'true'); const p = document.createElementNS('http://www.w3.org/2000/svg', 'path'); p.setAttribute('d', d); s.append(p); return s; };
const ICON = { up: 'M6 15l6-6 6 6', down: 'M6 9l6 6 6-6', left: 'M15 6l-6 6 6 6', right: 'M9 6l6 6-6 6', x: 'M5 5l14 14M19 5L5 19', star: 'M12 3l2.7 5.7 6.3.8-4.6 4.3 1.2 6.2L12 17l-5.6 3 1.2-6.2L3 9.5l6.3-.8z' };
const iconBtn = (name, label, onclick, extra = {}) => h('button', { class: `ib${extra.on ? ' on' : ''}`, type: 'button', 'aria-label': label, title: label, disabled: extra.disabled, 'aria-pressed': extra.on != null ? String(!!extra.on) : null, onclick }, svg(ICON[name]));

const slugify = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80);
const uid12 = () => [...crypto.getRandomValues(new Uint8Array(6))].map((b) => b.toString(16).padStart(2, '0')).join('');
const labelOf = (list, id) => (list.find((x) => x.id === id) || {}).label || '';

/* ---------------- login ---------------- */
function renderLogin(message) {
  const err = h('div', { class: 'err-box', role: 'alert', hidden: !message }, message || '');
  const user = h('input', { type: 'text', id: 'u', name: 'username', autocomplete: 'username', required: true, autocapitalize: 'none', spellcheck: 'false' });
  const pass = h('input', { type: 'password', id: 'p', name: 'password', autocomplete: 'current-password', required: true });
  const btn = h('button', { class: 'b b--primary', type: 'submit' }, 'Entrar');
  const form = h('form', { novalidate: true, onsubmit: async (e) => {
    e.preventDefault(); err.hidden = true; btn.disabled = true;
    try {
      const r = await api('POST', '/api/admin/login', { username: user.value, password: pass.value });
      state.csrf = r.csrf; state.me = r.user;
      await boot();
    } catch (ex) { err.textContent = ex.message; err.hidden = false; btn.disabled = false; pass.value = ''; pass.focus(); }
  } },
    err,
    h('div', { class: 'f' }, h('label', { for: 'u' }, 'Usuário'), user),
    h('div', { class: 'f' }, h('label', { for: 'p' }, 'Senha'), pass),
    btn);
  clear(app).append(h('main', { class: 'login' },
    h('img', { src: '/assets/logo/grow-original-branco.svg', width: 1080, height: 430, alt: 'Grow Engenharia' }),
    h('h1', null, 'Admin do portfólio'),
    form,
    h('a', { href: '/', class: 'muted' }, 'Voltar ao portfólio')));
  user.focus();
}

/* ---------------- shell ---------------- */
function shell(active, content) {
  const link = (href, text, key) => h('a', { href, 'aria-current': active === key ? 'page' : null }, text);
  clear(app).append(
    h('header', { class: 'top' },
      h('a', { class: 'top__logo', href: '#/obras', 'aria-label': 'Grow Engenharia — Admin' }, h('img', { src: '/assets/logo/grow-original-branco.svg', width: 1080, height: 430, alt: 'Grow Engenharia' })),
      h('nav', { 'aria-label': 'Admin' }, link('#/obras', 'Obras', 'obras'), link('#/taxonomia', 'Categorias e segmentos', 'taxonomia'), link('#/conta', 'Conta e acessos', 'conta'),
        h('a', { href: '/', target: '_blank', rel: 'noopener' }, 'Ver portfólio')),
      h('div', { class: 'top__user' }, h('span', null, state.me.username),
        h('button', { class: 'b b--ghost b--sm', type: 'button', onclick: logout }, 'Sair'))),
    content);
}
async function logout() {
  try { await api('POST', '/api/admin/logout'); } catch { /* sessão já expirada */ }
  state.me = null; state.csrf = '';
  renderLogin();
}
const banner = () => (state.dev ? h('div', { class: 'note', role: 'note' }, 'Esta conta usa a senha de desenvolvimento. Altere-a em “Conta e acessos” antes de publicar o site.') : null);

async function loadData() {
  const r = await api('GET', '/api/admin/projects');
  state.projects = r.projects; state.taxonomy = r.taxonomy; state.statuses = r.statuses;
}

/* ---------------- lista de obras ---------------- */
async function viewList() {
  shell('obras', h('main', { class: 'page' }, h('p', { class: 'muted' }, 'Carregando…')));
  await loadData();
  const render = () => {
    const rows = state.projects;
    const move = async (i, d) => {
      const j = i + d; if (j < 0 || j >= rows.length) return;
      [rows[i], rows[j]] = [rows[j], rows[i]];
      render();
      try { await api('POST', '/api/admin/projects/reorder', { ids: rows.map((p) => p.id) }); toast('Ordem salva.'); }
      catch (e) { toast(e.message, true); await loadData(); render(); }
    };
    let dragId = null;
    const list = h('ul', { class: 'plist', 'aria-label': 'Obras' }, rows.map((p, i) => {
      const cover = p.photos.find((x) => x.id === p.coverPhotoId) || p.photos[0];
      const li = h('li', { class: 'prow', draggable: 'true',
        ondragstart: (e) => { dragId = p.id; e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', p.id); } catch { /* */ } },
        ondragover: (e) => { if (dragId && dragId !== p.id) { e.preventDefault(); li.classList.add('is-drop'); } },
        ondragleave: () => li.classList.remove('is-drop'),
        ondrop: async (e) => {
          e.preventDefault(); li.classList.remove('is-drop');
          const from = rows.findIndex((x) => x.id === dragId); if (from < 0 || from === i) return;
          const [it] = rows.splice(from, 1); rows.splice(i, 0, it); render();
          try { await api('POST', '/api/admin/projects/reorder', { ids: rows.map((x) => x.id) }); toast('Ordem salva.'); } catch (ex) { toast(ex.message, true); }
        },
        ondragend: () => { dragId = null; } },
        h('div', { class: 'prow__order' }, iconBtn('up', `Subir ${p.name}`, () => move(i, -1), { disabled: i === 0 }), iconBtn('down', `Descer ${p.name}`, () => move(i, 1), { disabled: i === rows.length - 1 })),
        h('div', { class: 'prow__thumb' }, cover ? h('img', { src: cover.thumb || cover.src, alt: '', loading: 'lazy' }) : null),
        h('div', { class: 'prow__main' },
          h('span', { class: 'prow__name' }, p.name),
          h('div', { class: 'prow__meta' },
            h('span', { class: `tag ${p.published ? 'tag--pub' : 'tag--draft'}` }, p.published ? 'Publicada' : 'Rascunho'),
            h('span', null, labelOf(state.statuses, p.status) + (p.status === 'execucao' && p.progress != null ? ` ${p.progress}%` : '')),
            [labelOf(state.taxonomy.segments, p.segment), place(p)].filter(Boolean).map((t) => h('span', null, t)),
            h('span', null, `${p.photos.length} ${p.photos.length === 1 ? 'foto' : 'fotos'}`))),
        h('div', { class: 'prow__actions' },
          h('a', { class: 'b b--ghost b--sm', href: `#/obra/${p.id}` }, 'Editar'),
          h('a', { class: 'b b--ghost b--sm', href: `/obra/${p.slug}?preview=1`, target: '_blank', rel: 'noopener' }, p.published ? 'Ver no site' : 'Pré-visualizar'),
          h('button', { class: 'b b--ghost b--sm', type: 'button', onclick: async () => {
            if (!p.published && !p.photos.length) return toast('Adicione ao menos uma foto para publicar.', true);
            try { const r = await api('PUT', `/api/admin/projects/${p.id}`, { ...p, published: !p.published }); Object.assign(p, r.project); toast(p.published ? 'Obra publicada.' : 'Obra movida para rascunho.'); render(); }
            catch (e) { toast(e.fields && Object.values(e.fields)[0] || e.message, true); }
          } }, p.published ? 'Despublicar' : 'Publicar'),
          h('button', { class: 'b b--danger b--sm', type: 'button', onclick: async () => {
            if (!(await confirmBox({ title: `Excluir “${p.name}”?`, text: 'A obra e todas as suas fotos e vídeos enviados serão apagados. Esta ação não pode ser desfeita.', ok: 'Excluir obra', danger: true }))) return;
            try { await api('DELETE', `/api/admin/projects/${p.id}`); state.projects = state.projects.filter((x) => x.id !== p.id); toast('Obra excluída.'); render(); } catch (e) { toast(e.message, true); }
          } }, 'Excluir')));
      return li;
    }));
    const content = h('main', { class: 'page' },
      banner(),
      h('div', { class: 'page__head' },
        h('div', null, h('h1', null, 'Obras'), h('p', null, `${rows.length} ${rows.length === 1 ? 'obra' : 'obras'} — ${rows.filter((p) => p.published).length} publicada(s). A ordem desta lista é a ordem do portfólio.`)),
        h('a', { class: 'b b--primary', href: '#/obra/novo' }, 'Nova obra')),
      rows.length ? list : h('div', { class: 'empty' }, h('strong', null, 'Nenhuma obra cadastrada.'), h('p', null, 'Crie a primeira obra, adicione as fotos e publique.'), h('a', { class: 'b b--primary', href: '#/obra/novo' }, 'Nova obra')));
    shell('obras', content);
  };
  render();
}

/* ---------------- processamento e upload de imagens ---------------- */
async function processImage(file) {
  let bmp;
  try { bmp = await createImageBitmap(file, { imageOrientation: 'from-image' }); }
  catch { throw new Error(`Não foi possível ler “${file.name}”. Use JPG, PNG ou WebP.`); }
  const make = async (max, q) => {
    const s = Math.min(1, max / Math.max(bmp.width, bmp.height));
    const w = Math.max(1, Math.round(bmp.width * s)), hh = Math.max(1, Math.round(bmp.height * s));
    const c = document.createElement('canvas'); c.width = w; c.height = hh;
    const ctx = c.getContext('2d'); ctx.imageSmoothingQuality = 'high'; ctx.drawImage(bmp, 0, 0, w, hh);
    let blob = await new Promise((res) => c.toBlob(res, 'image/webp', q));
    if (!blob || blob.type !== 'image/webp') blob = await new Promise((res) => c.toBlob(res, 'image/jpeg', 0.86));
    return { blob, w, h: hh };
  };
  const full = await make(2400, 0.82), thumb = await make(900, 0.78);
  bmp.close && bmp.close();
  return { full, thumb };
}

function xhrUpload(url, blob, onProgress) {
  return new Promise((resolve, reject) => {
    const x = new XMLHttpRequest();
    x.open('POST', url);
    x.setRequestHeader('X-CSRF-Token', state.csrf);
    x.setRequestHeader('Content-Type', 'application/octet-stream');
    x.upload.onprogress = (e) => e.lengthComputable && onProgress && onProgress(e.loaded / e.total);
    x.onload = () => { let d = {}; try { d = JSON.parse(x.responseText); } catch { /* */ } x.status >= 200 && x.status < 300 ? resolve(d) : reject(new ApiError(d.error || `Falha no envio (${x.status}).`, x.status)); };
    x.onerror = () => reject(new ApiError('Falha de rede durante o envio.', 0));
    x.send(blob);
  });
}

/* ---------------- editor de obra ---------------- */
const blank = () => ({ name: '', slug: '', category: '', segment: '', city: '', uf: '', description: '', area: '', year: '', method: '', status: 'planejamento', progress: '', extra: [], photos: [], coverPhotoId: null, videos: [], published: false });

async function viewEditor(idParam) {
  shell('obras', h('main', { class: 'page' }, h('p', { class: 'muted' }, 'Carregando…')));
  if (!state.taxonomy) await loadData();
  let draft = blank(), isNew = idParam === 'novo', slugTouched = false;
  if (!isNew) {
    try { draft = { ...blank(), ...(await api('GET', `/api/admin/projects/${idParam}`)).project }; slugTouched = true; }
    catch (e) { return shell('obras', h('main', { class: 'page' }, h('div', { class: 'empty' }, h('strong', null, 'Obra não encontrada.'), h('a', { class: 'b b--primary', href: '#/obras' }, 'Voltar para obras')))); }
  }
  draft.area = draft.area ?? ''; draft.year = draft.year ?? ''; draft.progress = draft.progress ?? '';
  const snapshot = () => JSON.stringify({ ...draft });
  let saved = snapshot(), errs = {}, pending = 0, saving = false;
  const dirty = () => snapshot() !== saved;
  window.onbeforeunload = () => (dirty() || pending ? 'Há alterações não salvas.' : undefined);

  const root = h('main', { class: 'page' });
  const savebarHost = h('div');
  const statusLine = h('span', { class: 'savebar__state' });

  const err = (k) => (errs[k] ? h('span', { class: 'err' }, errs[k]) : null);
  const field = (k, label, input, hint) => h('div', { class: `f${errs[k] ? ' has-err' : ''}` }, h('label', { for: `f-${k}` }, label), input, hint ? h('small', null, hint) : null, err(k));
  const bind = (k, o = {}) => h('input', { type: o.type || 'text', id: `f-${k}`, value: draft[k] ?? '', maxlength: o.max || null, inputmode: o.mode || null, min: o.min ?? null, max: o.maxv ?? null, step: o.step ?? null, placeholder: o.ph || null, autocomplete: 'off', oninput: (e) => { draft[k] = e.target.value; if (o.after) o.after(); refreshBar(); } });
  const sel = (k, options, blankLabel) => {
    const s = h('select', { id: `f-${k}`, onchange: (e) => { draft[k] = e.target.value; refreshBar(); } }, h('option', { value: '' }, blankLabel), options.map((o) => h('option', { value: o.id }, o.label)));
    s.value = draft[k] || ''; return s;
  };

  function refreshBar() {
    const bar = clear(savebarHost);
    const busy = pending > 0 || saving;
    const pub = draft.published;
    statusLine.replaceChildren(
      pending ? h('b', null, `Enviando ${pending} arquivo(s)…`) : dirty() ? h('b', null, 'Alterações não salvas') : h('span', null, isNew ? 'Obra ainda não salva' : 'Tudo salvo'),
      h('span', null, ` — ${pub ? 'publicada' : 'rascunho'}`));
    bar.append(h('div', { class: 'savebar' }, h('div', { class: 'savebar__in' }, statusLine,
      h('a', { class: 'b b--ghost', href: '#/obras', onclick: async (e) => { if (dirty() && !(await confirmBox({ title: 'Sair sem salvar?', text: 'As alterações desta obra serão perdidas.', ok: 'Sair sem salvar', danger: true }))) e.preventDefault(); } }, 'Voltar'),
      pub
        ? [h('button', { class: 'b b--ghost', type: 'button', disabled: busy, onclick: () => save(false) }, 'Mover para rascunho'), h('button', { class: 'b b--primary', type: 'button', disabled: busy, onclick: () => save(true) }, 'Salvar alterações')]
        : [h('button', { class: 'b b--ghost', type: 'button', disabled: busy, onclick: () => save(false) }, 'Salvar rascunho'), h('button', { class: 'b b--primary', type: 'button', disabled: busy, onclick: () => save(true) }, 'Publicar')])));
  }

  async function save(publish) {
    if (pending) return toast('Aguarde o término dos envios.', true);
    saving = true; errs = {}; refreshBar();
    const payload = { ...draft, published: publish };
    try {
      const r = isNew ? await api('POST', '/api/admin/projects', payload) : await api('PUT', `/api/admin/projects/${draft.id}`, payload);
      draft = { ...blank(), ...r.project }; draft.area = draft.area ?? ''; draft.year = draft.year ?? ''; draft.progress = draft.progress ?? '';
      saved = snapshot(); saving = false;
      state.projects = [];
      toast(publish ? (isNew || !payloadWasPublished ? 'Obra publicada.' : 'Alterações salvas.') : 'Rascunho salvo.');
      if (isNew) { isNew = false; history.replaceState(null, '', `#/obra/${draft.id}`); }
      payloadWasPublished = publish;
      render();
    } catch (e) {
      saving = false; errs = e.fields || {};
      toast(e.message, true); render();
      const first = Object.keys(errs)[0]; if (first) { const el = root.querySelector(`#f-${first}`) || root.querySelector(`[data-sec="${first}"]`); el && el.scrollIntoView({ block: 'center', behavior: 'smooth' }); el && el.focus && el.focus({ preventScroll: true }); }
    }
  }
  let payloadWasPublished = draft.published;

  /* ----- fotos ----- */
  const photosHost = h('div');
  function renderPhotos(pendingItems = []) {
    const grid = h('div', { class: 'photos' });
    let dragIdx = null;
    draft.photos.forEach((p, i) => {
      const isCover = draft.coverPhotoId === p.id;
      const card = h('div', { class: `ph${isCover ? ' is-cover' : ''}`, draggable: 'true',
        ondragstart: (e) => { dragIdx = i; e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', String(i)); } catch { /* */ } },
        ondragover: (e) => { if (dragIdx !== null && dragIdx !== i) { e.preventDefault(); card.classList.add('is-drop'); } },
        ondragleave: () => card.classList.remove('is-drop'),
        ondrop: (e) => { e.preventDefault(); if (dragIdx === null || dragIdx === i) return; const [it] = draft.photos.splice(dragIdx, 1); draft.photos.splice(i, 0, it); dragIdx = null; refreshAll(); },
        ondragend: () => { dragIdx = null; } },
        h('div', { class: 'ph__img' }, h('img', { src: p.thumb || p.src, alt: p.alt || `Foto ${i + 1}`, loading: 'lazy' }), isCover ? h('span', { class: 'ph__badge' }, 'Foto principal') : null),
        h('div', { class: 'ph__tools' },
          iconBtn('star', isCover ? 'Foto principal' : 'Definir como foto principal', () => { draft.coverPhotoId = p.id; refreshAll(); }, { on: isCover }),
          iconBtn('left', 'Mover para trás', () => { [draft.photos[i - 1], draft.photos[i]] = [draft.photos[i], draft.photos[i - 1]]; refreshAll(); }, { disabled: i === 0 }),
          iconBtn('right', 'Mover para frente', () => { [draft.photos[i + 1], draft.photos[i]] = [draft.photos[i], draft.photos[i + 1]]; refreshAll(); }, { disabled: i === draft.photos.length - 1 }),
          iconBtn('x', 'Remover foto', () => { draft.photos.splice(i, 1); if (draft.coverPhotoId === p.id) draft.coverPhotoId = draft.photos[0] ? draft.photos[0].id : null; refreshAll(); })),
        h('input', { type: 'text', value: p.alt || '', maxlength: 200, placeholder: 'Descrição da foto (opcional)', 'aria-label': `Descrição da foto ${i + 1}`, oninput: (e) => { p.alt = e.target.value; refreshBar(); } }));
      grid.append(card);
    });
    for (const it of pendingItems) grid.append(it.el);

    const input = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp,image/avif', multiple: true, hidden: true, id: 'photo-input', onchange: (e) => { addFiles([...e.target.files]); e.target.value = ''; } });
    const drop = h('div', { class: 'drop', ondragover: (e) => { if ([...(e.dataTransfer.types || [])].includes('Files')) { e.preventDefault(); drop.classList.add('is-over'); } }, ondragleave: () => drop.classList.remove('is-over'),
      ondrop: (e) => { if (e.dataTransfer.files && e.dataTransfer.files.length) { e.preventDefault(); drop.classList.remove('is-over'); addFiles([...e.dataTransfer.files]); } } },
      h('p', null, 'Arraste fotos aqui ou escolha no dispositivo. Elas são otimizadas (WebP) antes do envio.'),
      h('button', { class: 'b', type: 'button', onclick: () => input.click() }, 'Adicionar fotos'), input);
    clear(photosHost).append(drop, draft.photos.length || pendingItems.length ? grid : h('p', { class: 'muted' }, 'Nenhuma foto ainda.'), err('photos'));
  }
  const pendingEls = [];
  async function addFiles(files) {
    files = files.filter((f) => /^image\//.test(f.type) || /\.(jpe?g|png|webp|avif)$/i.test(f.name));
    if (!files.length) return toast('Escolha arquivos de imagem (JPG, PNG, WebP).', true);
    for (const file of files) {
      const barEl = h('i'); const label = h('span', null, file.name);
      const el = h('div', { class: 'ph' }, h('div', { class: 'ph__pending' }, label, h('div', { class: 'bar' }, barEl)));
      const item = { el }; pendingEls.push(item); pending++; renderPhotos(pendingEls); refreshBar();
      try {
        const { full, thumb } = await processImage(file);
        const group = uid12();
        const a = await xhrUpload(`/api/admin/upload?kind=image&group=${group}`, full.blob, (f) => { barEl.style.width = `${f * 70}%`; });
        const b = await xhrUpload(`/api/admin/upload?kind=image&variant=thumb&group=${group}`, thumb.blob, (f) => { barEl.style.width = `${70 + f * 30}%`; });
        const photo = { id: uid12(), src: a.url, thumb: b.url, w: full.w, h: full.h, alt: '' };
        draft.photos.push(photo);
        if (!draft.coverPhotoId) draft.coverPhotoId = photo.id;
      } catch (e) { toast(e.message, true); }
      pendingEls.splice(pendingEls.indexOf(item), 1); pending--;
      renderPhotos(pendingEls); refreshBar();
    }
  }

  /* ----- vídeos ----- */
  const videosHost = h('div');
  function renderVideos(uploading) {
    const urlIn = h('input', { type: 'url', id: 'v-url', placeholder: 'Link do YouTube ou Vimeo', 'aria-label': 'Link do vídeo' });
    const fileIn = h('input', { type: 'file', accept: 'video/mp4,video/webm,video/quicktime', hidden: true, onchange: async (e) => { const f = e.target.files[0]; e.target.value = ''; if (f) uploadVideo(f); } });
    const list = draft.videos.map((v, i) => h('div', { class: 'vrow' },
      h('div', { class: 'vrow__head' }, h('strong', null, v.type === 'file' ? 'Arquivo de vídeo' : v.provider === 'vimeo' ? 'Vimeo' : 'YouTube'),
        h('div', { class: 'ph__tools' },
          iconBtn('up', 'Subir vídeo', () => { [draft.videos[i - 1], draft.videos[i]] = [draft.videos[i], draft.videos[i - 1]]; refreshAll(); }, { disabled: i === 0 }),
          iconBtn('down', 'Descer vídeo', () => { [draft.videos[i + 1], draft.videos[i]] = [draft.videos[i], draft.videos[i + 1]]; refreshAll(); }, { disabled: i === draft.videos.length - 1 }),
          iconBtn('x', 'Remover vídeo', () => { draft.videos.splice(i, 1); refreshAll(); }))),
      h('span', { class: 'vrow__src' }, v.type === 'file' ? v.src : (v.originalUrl || v.src)),
      h('input', { type: 'text', value: v.title || '', maxlength: 140, placeholder: 'Título do vídeo (opcional)', 'aria-label': 'Título do vídeo', oninput: (e) => { v.title = e.target.value; refreshBar(); } })));
    const addLink = () => {
      const url = urlIn.value.trim(); if (!url) return;
      if (!/^https?:\/\/(www\.|m\.)?(youtube\.com|youtu\.be|vimeo\.com|player\.vimeo\.com)\//i.test(url)) return toast('Use um link do YouTube ou do Vimeo.', true);
      draft.videos.push({ id: uid12(), type: 'embed', url, title: '' }); refreshAll();
    };
    clear(videosHost).append(
      list.length ? h('div', { style: { display: 'grid', gap: '12px' } }, list) : h('p', { class: 'muted' }, 'Nenhum vídeo ainda.'),
      h('div', { class: 'f' }, h('label', { for: 'v-url' }, 'Adicionar por link'),
        h('div', { class: 'addrow' }, urlIn, h('button', { class: 'b', type: 'button', onclick: addLink }, 'Adicionar link')),
        h('small', null, 'Os vídeos só começam quando o visitante toca em reproduzir (sem áudio automático).')),
      h('div', { class: 'f' }, h('span', { class: 'lbl' }, 'Ou enviar arquivo'),
        uploading ? h('div', null, h('span', null, uploading.name), h('div', { class: 'bar' }, uploading.bar)) : h('button', { class: 'b', type: 'button', onclick: () => fileIn.click() }, 'Enviar vídeo (MP4, WebM, MOV)'), fileIn,
        h('small', null, 'Prefira MP4 (H.264) de até algumas centenas de MB. Para arquivos muito pesados, use um link do YouTube/Vimeo.')),
      err('videos'));
  }
  async function uploadVideo(file) {
    const bar = h('i'); pending++; renderVideos({ name: file.name, bar }); refreshBar();
    try {
      const r = await xhrUpload('/api/admin/upload?kind=video', file, (f) => { bar.style.width = `${f * 100}%`; });
      draft.videos.push({ id: uid12(), type: 'file', src: r.url, title: file.name.replace(/\.[^.]+$/, '') });
    } catch (e) { toast(e.message, true); }
    pending--; renderVideos(); refreshBar();
  }

  /* ----- informações adicionais ----- */
  const extraHost = h('div');
  function renderExtra() {
    clear(extraHost).append(
      h('div', { style: { display: 'grid', gap: '10px' } }, draft.extra.map((e, i) => h('div', { class: 'erow' },
        h('div', { class: 'f' }, h('label', { for: `ex-l${i}` }, 'Informação'), h('input', { type: 'text', id: `ex-l${i}`, value: e.label, maxlength: 60, placeholder: 'Ex.: Pavimentos', oninput: (ev) => { e.label = ev.target.value; refreshBar(); } })),
        h('div', { class: 'f' }, h('label', { for: `ex-v${i}` }, 'Valor'), h('input', { type: 'text', id: `ex-v${i}`, value: e.value, maxlength: 200, oninput: (ev) => { e.value = ev.target.value; refreshBar(); } })),
        iconBtn('x', 'Remover informação', () => { draft.extra.splice(i, 1); renderExtra(); refreshBar(); })))),
      h('div', null, h('button', { class: 'b b--ghost b--sm', type: 'button', style: { marginTop: '10px' }, onclick: () => { draft.extra.push({ label: '', value: '' }); renderExtra(); refreshBar(); } }, 'Adicionar informação')));
  }

  /* ----- status e progresso ----- */
  const progHost = h('div');
  function renderProgress() {
    clear(progHost);
    if (draft.status !== 'execucao') return;
    const num = h('input', { type: 'number', min: 0, max: 100, step: 1, id: 'f-progress', value: draft.progress, 'aria-label': 'Percentual de andamento', oninput: (e) => { draft.progress = e.target.value; range.value = e.target.value || 0; refreshBar(); } });
    const range = h('input', { type: 'range', min: 0, max: 100, step: 1, value: draft.progress || 0, 'aria-label': 'Ajustar percentual', oninput: (e) => { draft.progress = e.target.value; num.value = e.target.value; refreshBar(); } });
    progHost.append(h('div', { class: `f prog${errs.progress ? ' has-err' : ''}` }, h('span', { class: 'lbl' }, 'Percentual de andamento'),
      h('div', { class: 'prog__row' }, range, num),
      h('div', { class: 'prog__quick' }, [25, 50, 75, 100].map((n) => h('button', { class: 'b b--ghost b--sm', type: 'button', onclick: () => { draft.progress = String(n); num.value = n; range.value = n; refreshBar(); } }, `${n}%`))),
      err('progress')));
  }

  function refreshAll() { renderPhotos(pendingEls); renderVideos(); renderExtra(); renderProgress(); refreshBar(); }

  function render() {
    const T = state.taxonomy;
    const statusSeg = h('div', { class: 'seg', role: 'radiogroup', 'aria-label': 'Status da obra' }, state.statuses.map((s) => {
      const r = h('input', { type: 'radio', name: 'status', value: s.id, checked: draft.status === s.id, onchange: () => { draft.status = s.id; renderProgress(); refreshBar(); } });
      return h('label', null, r, s.label);
    }));
    const slugIn = bind('slug', { max: 80, after: () => { slugTouched = true; } });
    const nameIn = bind('name', { max: 120, ph: 'Nome da obra', after: () => { if (!slugTouched && isNew) { draft.slug = slugify(draft.name); slugIn.value = draft.slug; } } });

    clear(root).append(
      banner(),
      h('div', { class: 'page__head' }, h('div', null, h('h1', null, isNew ? 'Nova obra' : draft.name || 'Obra'), h('p', null, isNew ? 'Preencha o que souber: campos vazios simplesmente não aparecem no portfólio.' : `Endereço: /obra/${draft.slug}`)),
        !isNew ? h('a', { class: 'b b--ghost', href: `/obra/${draft.slug}?preview=1`, target: '_blank', rel: 'noopener' }, 'Pré-visualizar') : null),
      Object.keys(errs).length ? h('div', { class: 'err-box', role: 'alert' }, 'Revise os campos destacados.') : null,

      h('section', { class: 'sec' }, h('h2', null, 'Identificação'),
        field('name', 'Nome da obra', nameIn),
        h('div', { class: 'grid2' }, field('category', 'Categoria', sel('category', T.categories, 'Selecione')), field('segment', 'Segmento', sel('segment', T.segments, 'Selecione'), 'Novos segmentos em “Categorias e segmentos”.')),
        h('div', { class: 'grid3' }, field('city', 'Cidade', bind('city', { max: 80 })), field('uf', 'UF', bind('uf', { max: 2, ph: 'SP' })), field('year', 'Ano', bind('year', { type: 'number', mode: 'numeric', min: 1950, maxv: 2100, ph: '2026' }))),
        field('slug', 'Endereço da página', slugIn, 'Parte final do link: /obra/…')),

      h('section', { class: 'sec' }, h('h2', null, 'Status'),
        h('div', { class: 'f' }, h('span', { class: 'lbl' }, 'Situação da obra'), statusSeg, err('status')), progHost),

      h('section', { class: 'sec' }, h('h2', null, 'Informações técnicas'),
        h('div', { class: 'grid2' }, field('area', 'Área (m²)', bind('area', { type: 'number', mode: 'decimal', min: 0, step: 'any' })), field('method', 'Método construtivo', bind('method', { max: 160 }), 'Preencha somente se confirmado.')),
        h('div', { class: 'f' }, h('span', { class: 'lbl' }, 'Outras informações'), extraHost)),

      h('section', { class: 'sec' }, h('h2', null, 'Sobre a obra'),
        h('div', { class: 'f' }, h('label', { for: 'f-description' }, 'Descrição'), h('textarea', { id: 'f-description', maxlength: 6000, oninput: (e) => { draft.description = e.target.value; refreshBar(); } }, draft.description || ''), h('small', null, 'Deixe uma linha em branco para separar parágrafos.'))),

      h('section', { class: 'sec', 'data-sec': 'photos' }, h('h2', null, 'Fotos'), h('p', { class: 'hint' }, 'A foto principal abre a obra e aparece no portfólio. Arraste para reordenar ou use as setas.'), photosHost),
      h('section', { class: 'sec', 'data-sec': 'videos' }, h('h2', null, 'Vídeos'), videosHost),
      savebarHost);
    refreshAll();
  }

  shell('obras', root);
  render();
}

/* ---------------- categorias e segmentos ---------------- */
async function viewTaxonomy() {
  shell('taxonomia', h('main', { class: 'page' }, h('p', { class: 'muted' }, 'Carregando…')));
  await loadData();
  const block = (kind, title) => {
    const host = h('div', { class: 'sec' });
    const draw = () => {
      const items = state.taxonomy[kind];
      const add = h('input', { type: 'text', maxlength: 60, placeholder: `Novo item`, 'aria-label': `Novo item de ${title.toLowerCase()}` });
      const addBtn = h('button', { class: 'b', type: 'button', onclick: async () => {
        if (!add.value.trim()) return;
        try { state.taxonomy = (await api('POST', `/api/admin/taxonomy/${kind}`, { label: add.value })).taxonomy; toast('Item adicionado.'); draw(); } catch (e) { toast(e.message, true); }
      } }, 'Adicionar');
      clear(host).append(h('h2', null, title), ...items.map((it) => {
        const inp = h('input', { type: 'text', value: it.label, maxlength: 60, 'aria-label': `Nome de ${it.label}` });
        return h('div', { class: 'trow' }, inp,
          h('button', { class: 'b b--ghost b--sm', type: 'button', onclick: async () => { try { state.taxonomy = (await api('PUT', `/api/admin/taxonomy/${kind}/${it.id}`, { label: inp.value })).taxonomy; toast('Nome salvo.'); draw(); } catch (e) { toast(e.message, true); } } }, 'Salvar nome'),
          h('button', { class: 'b b--danger b--sm', type: 'button', onclick: async () => {
            if (!(await confirmBox({ title: `Excluir “${it.label}”?`, text: 'Só é possível excluir itens que nenhuma obra esteja usando.', ok: 'Excluir', danger: true }))) return;
            try { state.taxonomy = (await api('DELETE', `/api/admin/taxonomy/${kind}/${it.id}`)).taxonomy; toast('Item excluído.'); draw(); } catch (e) { toast(e.message, true); }
          } }, 'Excluir'));
      }), h('div', { class: 'addrow' }, add, addBtn));
    };
    draw(); return host;
  };
  shell('taxonomia', h('main', { class: 'page' }, banner(),
    h('div', { class: 'page__head' }, h('div', null, h('h1', null, 'Categorias e segmentos'), h('p', null, 'Segmentos e categorias aparecem nos filtros do portfólio assim que houver obras publicadas com eles.'))),
    h('div', { class: 'two' }, block('categories', 'Categorias'), block('segments', 'Segmentos'))));
}

/* ---------------- conta e acessos ---------------- */
async function viewAccount() {
  shell('conta', h('main', { class: 'page' }, h('p', { class: 'muted' }, 'Carregando…')));
  const { users } = await api('GET', '/api/admin/users');
  const form = (title, fields, submitLabel, onSubmit) => {
    const box = h('div', { class: 'err-box', role: 'alert', hidden: true });
    const f = h('form', { novalidate: true, class: 'sec', onsubmit: async (e) => {
      e.preventDefault(); box.hidden = true;
      try { await onSubmit(); f.reset(); } catch (ex) { box.textContent = ex.message; box.hidden = false; }
    } }, h('h2', null, title), box, ...fields, h('div', null, h('button', { class: 'b b--primary', type: 'submit' }, submitLabel)));
    return f;
  };
  const inp = (id, label, type, ac) => h('div', { class: 'f' }, h('label', { for: id }, label), h('input', { type, id, name: id, autocomplete: ac, required: true }));
  const curr = inp('cur', 'Senha atual', 'password', 'current-password'), next = inp('nxt', 'Nova senha (mínimo de 10 caracteres)', 'password', 'new-password');
  const pw = form('Alterar minha senha', [curr, next], 'Salvar nova senha', async () => {
    await api('POST', '/api/admin/account/password', { current: curr.querySelector('input').value, next: next.querySelector('input').value });
    state.dev = false; toast('Senha alterada.'); viewAccount();
  });
  const nu = inp('nu', 'Usuário', 'text', 'off'), np = inp('np', 'Senha inicial (mínimo de 10 caracteres)', 'password', 'new-password');
  const add = form('Adicionar administrador', [nu, np], 'Adicionar administrador', async () => {
    await api('POST', '/api/admin/users', { username: nu.querySelector('input').value, password: np.querySelector('input').value });
    toast('Administrador adicionado.'); viewAccount();
  });
  const list = h('div', { class: 'sec' }, h('h2', null, 'Administradores'), ...users.map((u) => h('div', { class: 'trow', style: { gridTemplateColumns: '1fr auto' } },
    h('span', null, h('strong', null, u.username), u.id === state.me.id ? ' (você)' : ''),
    u.id === state.me.id ? null : h('button', { class: 'b b--danger b--sm', type: 'button', onclick: async () => {
      if (!(await confirmBox({ title: `Remover ${u.username}?`, text: 'Esse administrador perderá o acesso imediatamente.', ok: 'Remover', danger: true }))) return;
      try { await api('DELETE', `/api/admin/users/${u.id}`); toast('Administrador removido.'); viewAccount(); } catch (e) { toast(e.message, true); }
    } }, 'Remover'))));
  shell('conta', h('main', { class: 'page' }, banner(), h('div', { class: 'page__head' }, h('div', null, h('h1', null, 'Conta e acessos'), h('p', null, `Você está conectado como ${state.me.username}.`))),
    h('div', { class: 'two' }, pw, list), add));
}

/* ---------------- roteador ---------------- */
async function route() {
  if (!state.me) return;
  window.onbeforeunload = null;
  const hash = location.hash.replace(/^#/, '') || '/obras';
  const m = /^\/obra\/([a-z0-9]+)$/.exec(hash);
  try {
    if (m) await viewEditor(m[1]);
    else if (hash === '/taxonomia') await viewTaxonomy();
    else if (hash === '/conta') await viewAccount();
    else await viewList();
    window.scrollTo(0, 0);
  } catch (e) { if (e.status !== 401) { toast(e.message, true); } }
}
window.addEventListener('hashchange', route);

async function boot() {
  try {
    const r = await api('GET', '/api/admin/me');
    state.me = r.user; state.csrf = r.csrf; state.dev = r.devCredentials && r.user.mustChangePassword;
  } catch { return renderLogin(); }
  await route();
}
boot();
